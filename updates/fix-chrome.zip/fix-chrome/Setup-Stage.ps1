# ============================================================================
# Setup-Stage.ps1  -  Stage sample data and modules for the emulation
# ----------------------------------------------------------------------------
# Benign. No external downloads, no dummy-binary generation. Run once on the
# initial host (Target 1) from an elevated PowerShell prompt before the chain.
#
#   .\Setup-Stage.ps1
#
# What it does:
#   * Creates C:\Users\Public\staging and copies the stage modules + sample data
#   * Seeds C:\Confidential with the synthetic PII/PCI files (exfil source)
# Everything it creates is removed by Cleanup-Target1.ps1 / Cleanup-Target2.ps1.
# ============================================================================
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $scriptDir 'lib\Common.ps1')

Write-Stage "SETUP - Staging files (benign)"

# --- Staging directory ---
$staging = $CBXEmu.StagingDir
if (-not (Test-Path $staging)) {
    New-Item -ItemType Directory -Force -Path $staging | Out-Null
    Write-Step "Created staging directory: $staging"
} else {
    Write-Step "Staging directory already present: $staging"
}

# --- Copy modules so lateral movement can push them to Target 2 ---
$modSrc = Join-Path $scriptDir 'modules'
if (Test-Path $modSrc) {
    Copy-Item -Path (Join-Path $modSrc '*') -Destination $staging -Force
    Write-Step "Copied stage modules to $staging"
}

# --- Copy sample data ---
$dataSrc = Join-Path $scriptDir 'data'
$dataFiles = Get-ChildItem -Path $dataSrc -File -ErrorAction SilentlyContinue
if ($dataFiles) {
    foreach ($f in $dataFiles) {
        Copy-Item -Path $f.FullName -Destination $staging -Force
        Write-Info "staged $($f.Name)"
    }
    Write-Step "Copied $($dataFiles.Count) sample data file(s) to $staging"
} else {
    Write-Step "WARNING: no sample data found in $dataSrc"
}

# --- Seed C:\Confidential (the 'sensitive' source the exfil stage reads) ---
$conf = $CBXEmu.ConfidentialDir
if (-not (Test-Path $conf)) {
    New-Item -ItemType Directory -Force -Path $conf | Out-Null
    Write-Step "Created $conf"
}
if ($dataFiles) {
    foreach ($f in $dataFiles) {
        Copy-Item -Path $f.FullName -Destination $conf -Force
    }
    Write-Step "Seeded $conf with synthetic sensitive files"
}

Write-StageEnd "SETUP"
Write-Host "[+] Setup complete. Sample data is synthetic (test PANs / fake passport patterns) only." -ForegroundColor Green
