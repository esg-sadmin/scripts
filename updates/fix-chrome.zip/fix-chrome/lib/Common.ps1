# ============================================================================
# Common.ps1  -  Shared helpers and configuration for the staged emulation
# ----------------------------------------------------------------------------
# Dot-sourced by Invoke-AttackChain.ps1 and by the stage modules when they run
# under the runner. Each stage module ALSO defines its own minimal logging so
# it can run standalone (or be copied to a second host) without this file.
# ============================================================================

# ---- Central configuration -------------------------------------------------
# One place to change artifact names/paths. Cleanup scripts read the same values.
$Global:CBXEmu = [ordered]@{
    StagingDir      = 'C:\Users\Public\staging'          # setup drops modules + sample data here
    ConfidentialDir = 'C:\Confidential'                  # synthetic "sensitive" source files
    FileshareDir    = 'C:\FileshareData'                 # lateral-movement drop target on Target 2
    ImpactDir       = 'C:\CBX_Test_Impact'               # ransomware sim operates ONLY here by default
    TaskName        = 'MSTeamsUpdater'                    # scheduled-task persistence name (masquerade)
    MasqueradeExe   = 'C:\Users\Public\ms_teams.exe'      # optional LOLBIN copy (masquerade)
    RansomExt       = '.akira'
    RansomNote      = 'akira_readme.txt'
    DumpFile        = "$env:APPDATA\error.dmp"            # LSASS dump output (masquerade name)
    ExfilSuffix     = '_exfil'                            # exfil copies: <name>_exfil.jpg
    ExfilExt        = '.jpg'                              # extension masquerade on exfil
}

function Write-Stage {
    param([string]$Title)
    $bar = '=' * 74
    Write-Host ""
    Write-Host $bar -ForegroundColor Cyan
    Write-Host "  $Title" -ForegroundColor Cyan
    Write-Host "  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff zzz'))" -ForegroundColor DarkCyan
    Write-Host $bar -ForegroundColor Cyan
}

function Write-StageEnd {
    param([string]$Title)
    Write-Host ("-" * 74) -ForegroundColor DarkCyan
    Write-Host "  END   $Title  $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff zzz'))" -ForegroundColor DarkCyan
    Write-Host ("-" * 74) -ForegroundColor DarkCyan
    Write-Host ""
}

function Write-Step {
    param([string]$Message)
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
    Write-Host "[$ts] $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([string]$Message)
    Write-Host "        $Message" -ForegroundColor DarkGray
}

function Assert-Admin {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "This step needs an elevated (Administrator) PowerShell session."
    }
}
