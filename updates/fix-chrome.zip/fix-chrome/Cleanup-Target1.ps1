# ============================================================================
# Cleanup-Target1.ps1  -  Remove all emulation artifacts from Host 1
# Version : 1.2  2026-10-05
# ----------------------------------------------------------------------------
# Benign. Run from an elevated PowerShell prompt on the initial host (Target 1)
# after completing or aborting an emulation run.
#
# Removes:
#   * MSTeamsUpdater scheduled task (Stage 3)
#   * C:\Users\Public\ms_teams.exe masquerade copy (Stage 3, if dropped)
#   * C:\Users\Public\lsass.dmp (Stage 2 - standard variant)
#   * C:\Users\Public\Procdump.zip + \temp + \winlogon_procdump.dmp +
#     \procdump_stderr.log (Stage 2 - WebDownload variant)
#   * *_exfil.jpg files from the current user's OneDrive folder (Stage 5)
#   * %USERPROFILE%\Documents\CBX-Combined-Test\ tree (Stage 6)
#   * C:\Confidential\ directory (Setup-Stage.ps1)
#   * C:\Users\Public\staging\ directory (Setup-Stage.ps1) -- removed LAST
#
# Safe to run more than once.
# ============================================================================
[CmdletBinding()]
param()

$ErrorActionPreference = 'Continue'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$libPath   = Join-Path $scriptDir 'lib\Common.ps1'
if (Test-Path $libPath) { . $libPath }

if (-not (Get-Command Write-Step  -ErrorAction SilentlyContinue)) {
    function Write-Step($m)     { Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t)    { Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t) { Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m)     { Write-Host "        $m" -ForegroundColor DarkGray }
}

$taskName   = if ($CBXEmu) { $CBXEmu.TaskName }       else { 'MSTeamsUpdater' }
$stagingDir = if ($CBXEmu) { $CBXEmu.StagingDir }     else { 'C:\Users\Public\staging' }
$masqExe    = if ($CBXEmu) { $CBXEmu.MasqueradeExe }  else { 'C:\Users\Public\ms_teams.exe' }
$confDir    = if ($CBXEmu) { $CBXEmu.ConfidentialDir } else { 'C:\Confidential' }
$lsassDump  = 'C:\Users\Public\lsass.dmp'
# Stage 2b (WebDownload variant) artifacts -- paths match Stage2b-WebDownloadCredAccess.ps1
$procZip    = 'C:\Users\Public\Procdump.zip'
$procTemp   = 'C:\Users\Public\temp'
$procDump   = 'C:\Users\Public\winlogon_procdump.dmp'
$procLog    = 'C:\Users\Public\procdump_stderr.log'
$removed    = 0
$skipped    = 0
$failed     = 0

Write-Stage "CLEANUP - TARGET 1"

# ── 1. Scheduled task ───────────────────────────────────────────────────────
Write-Step "Removing scheduled task '$taskName' (Stage 3)"
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    try {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
        Write-Info "removed '$taskName'"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove task '$taskName': $($_.Exception.Message)"
    }
} else {
    Write-Info "task '$taskName' not found -- already removed or never created"
    $skipped++
}

# ── 2. Masquerade copy ──────────────────────────────────────────────────────
Write-Step "Removing masquerade executable (Stage 3)"
if (Test-Path $masqExe) {
    try {
        Remove-Item $masqExe -Force -ErrorAction Stop
        Write-Info "removed $masqExe"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$masqExe': $($_.Exception.Message)"
    }
} else {
    Write-Info "$masqExe not found -- -DropMasqueradeCopy was likely not used"
    $skipped++
}

# ── 3. LSASS dump ───────────────────────────────────────────────────────────
Write-Step "Removing LSASS dump (Stage 2)"
if (Test-Path $lsassDump) {
    try {
        Remove-Item $lsassDump -Force -ErrorAction Stop
        Write-Info "removed $lsassDump"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$lsassDump': $($_.Exception.Message)"
    }
} else {
    Write-Info "$lsassDump not found -- Stage 2 may have been blocked or not run"
    $skipped++
}

# ── 3b. Stage 2b (WebDownload variant) artifacts ────────────────────────────
Write-Step "Removing Stage 2b WebDownload artifacts (ProcDump + dump + logs)"
# Paths pinned by Stage2b-WebDownloadCredAccess.ps1 so cleanup is deterministic
# (the module passes procdump -o $procDump to avoid procdump's default CWD
# behavior; keep these in sync if that path changes).
$stage2bPaths = @(
    $procZip,
    $procTemp,
    $procDump,
    $procLog
)
foreach ($p in $stage2bPaths) {
    if (Test-Path $p) {
        try {
            Remove-Item $p -Recurse -Force -ErrorAction Stop
            Write-Info "removed $p"
            $removed++
        } catch {
            $failed++
            Write-Warning "could not remove '$p': $($_.Exception.Message)"
        }
    } else {
        Write-Info "$p not found -- Stage 2 WebDownload variant may not have run"
        $skipped++
    }
}

# ── 4. Exfil copies in OneDrive (Stage 5) ───────────────────────────────────
Write-Step "Removing exfil copies (*_exfil.jpg) from OneDrive (Stage 5)"
$suffix  = if ($CBXEmu) { $CBXEmu.ExfilSuffix } else { '_exfil' }
$fakeExt = if ($CBXEmu) { $CBXEmu.ExfilExt }    else { '.jpg' }
$exfilPattern = "*$suffix$fakeExt"

# Resolve OneDrive path using the same chain Stage5 used
$odPath = $env:OneDriveCommercial
if (-not $odPath -or -not (Test-Path $odPath)) { $odPath = $env:OneDrive }
if (-not $odPath -or -not (Test-Path $odPath)) {
    $foundOD = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue |
                   ForEach-Object { Get-ChildItem $_.FullName -Directory -ErrorAction SilentlyContinue } |
                   Where-Object { $_.Name -like 'OneDrive*' } |
                   Select-Object -First 1
    if ($foundOD) { $odPath = $foundOD.FullName }
}
if (-not $odPath -or -not (Test-Path $odPath)) {
    $odPath = Join-Path $env:LOCALAPPDATA 'Temp\OneDrive'
}

if (Test-Path $odPath) {
    $exfilFiles = Get-ChildItem -Path $odPath -Filter $exfilPattern -File -ErrorAction SilentlyContinue
    if ($exfilFiles) {
        foreach ($f in $exfilFiles) {
            try {
                Remove-Item $f.FullName -Force -ErrorAction Stop
                Write-Info "removed $($f.FullName)"
                $removed++
            } catch {
                $failed++
                Write-Warning "could not remove '$($f.FullName)': $($_.Exception.Message)"
            }
        }
    } else {
        Write-Info "no $exfilPattern files found in $odPath"
        $skipped++
    }
} else {
    Write-Info "OneDrive path not found -- Stage 5 may not have run"
    $skipped++
}

# ── 5. Stage 6 synthetic file tree ──────────────────────────────────────────
Write-Step "Removing CBX-Combined-Test tree (Stage 6)"
$cbxTestRoot = Join-Path $env:USERPROFILE 'Documents\CBX-Combined-Test'
if (Test-Path $cbxTestRoot) {
    try {
        Remove-Item $cbxTestRoot -Recurse -Force -ErrorAction Stop
        Write-Info "removed $cbxTestRoot"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$cbxTestRoot': $($_.Exception.Message)"
    }
} else {
    Write-Info "$cbxTestRoot not found -- Stage 6 may not have run"
    $skipped++
}

# ── 6. C:\Confidential ──────────────────────────────────────────────────────
Write-Step "Removing synthetic sensitive data directory (Setup-Stage.ps1)"
if (Test-Path $confDir) {
    try {
        Remove-Item $confDir -Recurse -Force -ErrorAction Stop
        Write-Info "removed $confDir"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$confDir': $($_.Exception.Message)"
    }
} else {
    Write-Info "$confDir not found -- already removed or never created"
    $skipped++
}

# ── 7. Staging directory (LAST) ─────────────────────────────────────────────
Write-Step "Removing staging directory (Setup-Stage.ps1) -- last"
if (Test-Path $stagingDir) {
    try {
        Remove-Item $stagingDir -Recurse -Force -ErrorAction Stop
        Write-Info "removed $stagingDir"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$stagingDir': $($_.Exception.Message)"
    }
} else {
    Write-Info "$stagingDir not found -- already removed or Setup-Stage.ps1 never ran"
    $skipped++
}

Write-StageEnd "CLEANUP - TARGET 1"
$color = if ($failed -gt 0) { 'Red' } else { 'Green' }
Write-Host "[+] Target 1 cleanup complete. Removed: $removed  Already gone: $skipped  Failed: $failed" -ForegroundColor $color
