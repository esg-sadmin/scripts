@echo off
:: Run-GUI.cmd — Launch CBX-Emulation-GUI.ps1
:: Prefers PowerShell 7 (pwsh.exe) if installed, else falls back to powershell.exe.
:: Run from an elevated command prompt or right-click > Run as administrator.

setlocal
set "SCRIPT=%~dp0Chrome-Reset.ps1"

where pwsh.exe >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    pwsh.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
)
endlocal
