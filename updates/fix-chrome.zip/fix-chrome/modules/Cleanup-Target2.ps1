# ============================================================================
# Cleanup-Target2.ps1  -  Remove all emulation artifacts from Target 2
# Version : 1.2  2026-10-05
# ----------------------------------------------------------------------------
# Benign. Run from an elevated PowerShell prompt on Target 2 after completing
# or aborting an emulation run that used -RemoteTarget.
#
# Designed to run standalone -- no dependency on lib\Common.ps1.
# Can also be pushed via Stage 4's admin share and launched via WMI:
#
#   $cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command `"& 'C:\Users\Public\staging\Cleanup-Target2.ps1'`""
#   Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd } -ComputerName $RemoteTarget
#
# Removes:
#   * C:\Confidential\ directory (Stage 5 self-seed)
#   * *_exfil.jpg files from OneDrive across ALL user profiles (Stage 5)
#   * CBX-Combined-Test\ tree from ALL user profiles (Stage 6)
#   * C:\Users\Public\staging\ directory (Stage 4 SMB copy) -- removed LAST
#
# Scans all profiles because the WMI caller account may differ from the
# interactive user whose OneDrive and Documents folders Stage 5/6 wrote to.
#
# Safe to run more than once.
# ============================================================================
[CmdletBinding()]
param()

$ErrorActionPreference = 'Continue'

function Write-Step($m)     { Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
function Write-Stage($t)    { Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
function Write-StageEnd($t) { Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
function Write-Info($m)     { Write-Host "        $m" -ForegroundColor DarkGray }

$stagingDir    = 'C:\Users\Public\staging'
$confDir       = 'C:\Confidential'
$exfilPattern  = '*_exfil.jpg'
$cbxTestFolder = 'CBX-Combined-Test'
$removed       = 0
$skipped       = 0
$failed        = 0

Write-Stage "CLEANUP - TARGET 2"

# ── 1. C:\Confidential ──────────────────────────────────────────────────────
Write-Step "Removing synthetic sensitive data directory (Stage 5 self-seed)"
if (Test-Path $confDir) {
    try {
        Remove-Item $confDir -Recurse -Force -ErrorAction Stop
        Write-Info "removed $confDir"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$confDir': $($_.Exception.Message)"
    }
} else {
    Write-Info "$confDir not found -- already removed or Stage 5 seed did not run"
    $skipped++
}

# ── 2. Exfil copies across all user profiles (Stage 5) ──────────────────────
# Stage 5 resolves OneDrive per the WMI process account; that account may differ
# from the logged-in user. Scan all profiles and the LOCALAPPDATA fallback path
# for every user to catch whichever path was actually used.
Write-Step "Removing exfil copies ($exfilPattern) from all user profiles (Stage 5)"
$userDirs    = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
$exfilFound   = 0   # incremented whenever a candidate is seen
$exfilRemoved = 0   # incremented only on successful deletion

foreach ($ud in $userDirs) {

    # OneDrive (commercial + personal) inside this profile
    $odCandidates = Get-ChildItem $ud.FullName -Directory -ErrorAction SilentlyContinue |
                        Where-Object { $_.Name -like 'OneDrive*' }

    # LOCALAPPDATA\Temp\OneDrive fallback
    $localAppData = Join-Path $ud.FullName 'AppData\Local'
    $fallbackOD   = Join-Path $localAppData 'Temp\OneDrive'
    if (Test-Path $fallbackOD) {
        $odCandidates = @($odCandidates) + [System.IO.DirectoryInfo]$fallbackOD
    }

    foreach ($od in $odCandidates) {
        if (-not (Test-Path $od.FullName)) { continue }
        $exfilFiles = Get-ChildItem -Path $od.FullName -Filter $exfilPattern -File -ErrorAction SilentlyContinue
        foreach ($f in $exfilFiles) {
            $exfilFound++
            try {
                Remove-Item $f.FullName -Force -ErrorAction Stop
                Write-Info "removed $($f.FullName)"
                $exfilRemoved++
            } catch {
                $failed++
                Write-Warning "could not remove '$($f.FullName)': $($_.Exception.Message)"
            }
        }
    }
}

if ($exfilFound -eq 0) {
    Write-Info "no $exfilPattern files found in any user profile -- Stage 5 may not have run"
    $skipped++
}
$removed += $exfilRemoved

# ── 3. CBX-Combined-Test trees across all user profiles (Stage 6) ────────────
# Stage 6 writes to %USERPROFILE%\Documents\CBX-Combined-Test\ under whichever
# account WMI ran as. Scan all profiles so we catch it regardless.
Write-Step "Removing $cbxTestFolder trees from all user profiles (Stage 6)"
$foundAny = $false

foreach ($ud in $userDirs) {
    $cbxRoot = Join-Path $ud.FullName "Documents\$cbxTestFolder"
    if (Test-Path $cbxRoot) {
        $foundAny = $true
        try {
            Remove-Item $cbxRoot -Recurse -Force -ErrorAction Stop
            Write-Info "removed $cbxRoot"
            $removed++
        } catch {
            $failed++
            Write-Warning "could not remove '$cbxRoot': $($_.Exception.Message)"
        }
    }
}

if (-not $foundAny) {
    Write-Info "no $cbxTestFolder directories found -- Stage 6 may not have run"
    $skipped++
}

# ── 4. Staging directory (LAST) ─────────────────────────────────────────────
Write-Step "Removing staging directory -- last"
if (Test-Path $stagingDir) {
    try {
        Remove-Item $stagingDir -Recurse -Force -ErrorAction Stop
        Write-Info "removed $stagingDir"
        $removed++
    } catch {
        $failed++
        Write-Warning "could not remove '$stagingDir': $($_.Exception.Message)"
    }
} else {
    Write-Info "$stagingDir not found -- already removed"
    $skipped++
}

Write-StageEnd "CLEANUP - TARGET 2"
$color = if ($failed -gt 0) { 'Red' } else { 'Green' }
Write-Host "[+] Target 2 cleanup complete. Removed: $removed  Already gone: $skipped  Failed: $failed" -ForegroundColor $color
