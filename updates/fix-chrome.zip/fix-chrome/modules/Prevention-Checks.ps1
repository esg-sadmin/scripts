# ============================================================================
# Prevention-Checks.ps1   (POC-Prevention, block mode, guide section 6)
# ----------------------------------------------------------------------------
# The benign single-technique checks for the Prevention profile. These are
# meant to be BLOCKED at the first step on POC-Prevention, where success is the
# block plus the alert. They are intentionally small and self-contained.
#
# Included here:
#   6.3  certutil LOTL download   (T1105 / T1140)
#   6.3  encoded PowerShell       (T1059.001)
#   6.5  simple TCP port scan     (T1046)  - reuse Stage6 canary for 6.4 ransomware
#
# NOT scripted here (do these by hand, they need no code):
#   6.2  EICAR    - save the EICAR test string to a file on a POC-Prevention host
# ============================================================================
[CmdletBinding()]
param(
    [string]$LotlUrl = 'https://example.com/index.html',   # benign target; set a lab URL if preferred
    [string]$ScanTarget = '127.0.0.1',
    [int[]]$ScanPorts = @(135,139,445,3389,5985)
)

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}

Write-Stage "PREVENTION CHECKS (section 6, block mode)"

# --- 6.3 certutil LOTL download (T1105) ---
Write-Step "6.3  certutil LOTL download from $LotlUrl (T1105)"
$out = Join-Path $env:TEMP 'lotl_download.bin'
try { certutil.exe -urlcache -split -f $LotlUrl $out 2>&1 | Out-Host }
catch { Write-Info "certutil returned: $($_.Exception.Message)" }
Remove-Item $out -Force -ErrorAction SilentlyContinue
Write-Info "[i] A 404 above is expected -- example.com does not serve that file."
Write-Info "    CBX detects the network attempt (T1105), not the download result."

# --- 6.3 encoded PowerShell (T1059.001) ---
Write-Step "6.3  encoded PowerShell child process (T1059.001)"
$enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes("Write-Output 'CBX POC benign encoded test'"))
try { powershell.exe -NoProfile -EncodedCommand $enc | Out-Host }
catch { Write-Info "powershell returned: $($_.Exception.Message)" }

# --- 6.5 simple TCP connect scan (T1046) ---
Write-Step "6.5  TCP connect scan of $ScanTarget on $($ScanPorts -join ',') (T1046)"
foreach ($port in $ScanPorts) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect($ScanTarget, $port, $null, $null)
        $open = $iar.AsyncWaitHandle.WaitOne(300)
        Write-Info ("port {0,-5} : {1}" -f $port, ($(if ($open -and $client.Connected) {'open'} else {'closed/filtered'})))
    } catch { Write-Info "port $port : error" }
    finally { $client.Close() }
}

Write-Info "6.2 EICAR is a manual step - see header."
Write-Info "6.4 ransomware: run Stage6-Impact.ps1 (safe canary) on a POC-Prevention host."

Write-StageEnd "PREVENTION CHECKS"
