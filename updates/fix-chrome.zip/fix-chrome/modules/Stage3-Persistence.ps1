# ============================================================================
# Stage3-Persistence.ps1
# MITRE: T1053.005 Scheduled Task | T1059.001 PowerShell (encoded)
#        T1036.005 Masquerading (task name mimics a Teams updater)
# ----------------------------------------------------------------------------
# Benign. Registers a scheduled task named "MSTeamsUpdater" whose action is an
# ENCODED PowerShell command. The encoded command is deliberately harmless: it
# writes a single timestamped marker line to a log file under the staging dir.
# The point is the behavior CBX sees (a masquerading scheduled task launching
# powershell.exe with -EncodedCommand), not the payload.
#
# This directly feeds guide 7.5, the custom-detection example:
#   process_name:powershell.exe AND process_cmdline:(-enc OR -EncodedCommand)
#
# By default the task is registered and run once, then LEFT in place so the
# persistence artifact is visible in the console. Cleanup-Target1.ps1 removes
# it (or run this module with -RemoveOnly).
# ============================================================================
[CmdletBinding()]
param(
    [switch]$RemoveOnly,
    [switch]$DropMasqueradeCopy   # optional: also place a renamed LOLBIN copy (see note below)
)

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}
$taskName   = if ($CBXEmu) { $CBXEmu.TaskName }       else { 'MSTeamsUpdater' }
$stagingDir = if ($CBXEmu) { $CBXEmu.StagingDir }     else { 'C:\Users\Public\staging' }
$masqExe    = if ($CBXEmu) { $CBXEmu.MasqueradeExe }  else { 'C:\Users\Public\ms_teams.exe' }

Write-Stage "STAGE 3 - PERSISTENCE (scheduled task + encoded PowerShell)"

# --- remove any prior instance first (idempotent) ---
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    Write-Info "removed pre-existing task '$taskName'"
}
if (-not (Test-Path $stagingDir)) { New-Item -ItemType Directory -Force -Path $stagingDir | Out-Null }

if ($RemoveOnly) {
    if (Test-Path $masqExe) { Remove-Item $masqExe -Force -ErrorAction SilentlyContinue }
    Write-Step "RemoveOnly requested - persistence artifacts cleared."
    Write-StageEnd "STAGE 3 - PERSISTENCE"
    return
}

# --- build the BENIGN encoded command (writes one marker line to a log) ---
$logPath   = Join-Path $stagingDir 'msteamsupdater_marker.log'
$plainCmd  = "Add-Content -Path '$logPath' -Value ('MSTeamsUpdater ran ' + (Get-Date).ToString('o'))"
$bytes     = [System.Text.Encoding]::Unicode.GetBytes($plainCmd)
$encoded   = [System.Convert]::ToBase64String($bytes)
Write-Info "encoded command decodes to a single Add-Content marker write (benign)"

# --- register the scheduled task ---
$action    = New-ScheduledTaskAction -Execute 'powershell.exe' `
                -Argument "-NoProfile -WindowStyle Hidden -EncodedCommand $encoded"
$trigger   = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
                -Principal $principal -Description 'Microsoft Teams update helper' | Out-Null
Write-Step "Registered scheduled task '$taskName' (T1053.005) launching encoded powershell (T1059.001)"

# --- run it once now so the encoded-powershell process is observed immediately ---
Start-ScheduledTask -TaskName $taskName
Write-Step "Started task once to generate the encoded-PowerShell process event"

# --- optional masquerade copy (INFERENCE: original kit left ms_teams.exe behind) ---
if ($DropMasqueradeCopy) {
    Copy-Item -Path (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe') `
              -Destination $masqExe -Force -ErrorAction SilentlyContinue
    Write-Step "Dropped masquerade copy of powershell.exe as $masqExe (T1036.005)"
}

Write-StageEnd "STAGE 3 - PERSISTENCE"
