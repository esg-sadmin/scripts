<#
.SYNOPSIS
    Combined benign ransomware-behavior + CBX canary detection test.

.DESCRIPTION
    AUTHORIZED SECURITY TELEMETRY TESTING ONLY.

    The script:

      1. Creates its own unique synthetic-data directory under:
            %USERPROFILE%\Documents\CBX-Combined-Test

      2. Creates harmless synthetic documents.

      3. Performs ransomware-like activity ONLY against those
         synthetic files:
            - Reads
            - Direct in-place randomized overwrite
            - Rename to .locked
            - Delete
            - Rapid sequential processing

      4. After a configurable number of synthetic files have been
         processed, deletes exactly ONE explicitly supplied CBX
         canary file.

      5. Continues processing synthetic files if the process remains
         alive.

    IMPORTANT:
      - NO encryption is performed.
      - NO existing user documents are modified.
      - NO recursive user-profile enumeration occurs.
      - ONLY the explicitly supplied canary is touched.
      - NO security controls are disabled.
      - NO shadow copies are modified.
      - NO recovery settings are modified.
      - NO network shares are accessed.

.EXAMPLE
    powershell.exe -NoProfile -ExecutionPolicy Bypass `
        -File .\RanSimCanary.ps1 `
        -CanaryPath 'C:\Users\User\$12345678.pptx'

.EXAMPLE
    powershell.exe -NoProfile -ExecutionPolicy Bypass `
        -File .\RanSimCanary.ps1 `
        -CanaryPath 'C:\Users\User\$12345678.pptx' `
        -FileCount 200 `
        -CanaryAfter 50 `
        -DelayMs 0 `
        -Force

.NOTES
    Version : 1.2  2026-10-05
#>

[CmdletBinding()]
param (

    [Parameter(Mandatory = $false)]
    [string]$CanaryPath = '',

    [ValidateRange(20,500)]
    [int]$FileCount = 200,

    [ValidateRange(1,499)]
    [int]$CanaryAfter = 50,

    [ValidateRange(0,5000)]
    [int]$DelayMs = 0,

    [switch]$Force
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'


# =====================================================================
# DO NOT USE POWERSHELL ISE
# =====================================================================

if ($Host.Name -eq 'Windows PowerShell ISE Host') {

    throw (@(
        'Do not run this test from PowerShell ISE.',
        '',
        'Use a fresh powershell.exe process, for example:',
        '',
        "powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\RanSimCanary.ps1 -CanaryPath '<path>'"
    ) -join "`r`n")
}


$stage6TranscriptStarted = $false
try {
    Start-Transcript -Path 'C:\Users\Public\staging\stage6-log.txt' -Append -Force -ErrorAction Stop | Out-Null
    $stage6TranscriptStarted = $true
} catch { }

try {

# =====================================================================
# PARAMETER VALIDATION
# =====================================================================

if ($CanaryAfter -ge $FileCount) {

    throw (@(
        'CanaryAfter must be less than FileCount.',
        '',
        'Example:',
        '',
        '    -FileCount 200 -CanaryAfter 50'
    ) -join "`r`n")
}


# =====================================================================
# LOAD ASSEMBLIES
# =====================================================================

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Drawing


# =====================================================================
# PATH CONFIGURATION
# =====================================================================

$ProfileRoot = [System.IO.Path]::GetFullPath(
    $env:USERPROFILE
)

$BasePath = Join-Path `
    $ProfileRoot `
    'Documents\CBX-Combined-Test'

$RunName = 'CBX-Combined-{0}-{1}' -f `
    (Get-Date -Format 'yyyyMMdd-HHmmss'),
    ([Guid]::NewGuid().ToString('N').Substring(0,8))

$RunPath = [System.IO.Path]::GetFullPath(
    (Join-Path $BasePath $RunName)
)

$RunRoot = $RunPath.TrimEnd('\')


# =====================================================================
# SANDBOX SAFETY FUNCTION
# =====================================================================

function Assert-TestPath {

    param (
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $FullPath = [System.IO.Path]::GetFullPath($Path)

    $AllowedPrefix = $RunRoot + '\'

    if (
        ($FullPath -ne $RunRoot) -and
        (-not $FullPath.StartsWith(
            $AllowedPrefix,
            [System.StringComparison]::OrdinalIgnoreCase
        ))
    ) {

        throw (@(
            'SANDBOX SAFETY CHECK FAILED.',
            '',
            'Attempted path:',
            '',
            "    $FullPath",
            '',
            'Allowed synthetic-data root:',
            '',
            "    $RunRoot",
            '',
            'Operation aborted.'
        ) -join "`r`n")
    }

    return $FullPath
}


# =====================================================================
# AUTO-SELECT CANARY WHEN NOT SUPPLIED
# =====================================================================

if ([string]::IsNullOrWhiteSpace($CanaryPath)) {

    $AutoExts = @('.doc','.docx','.xls','.xlsx','.ppt','.pptx','.jpg','.jpeg')

    $AutoCandidates = @(Get-ChildItem `
        -LiteralPath $ProfileRoot `
        -File `
        -Force `
        -ErrorAction SilentlyContinue |
    Where-Object {
        ($AutoExts -contains $_.Extension.ToLowerInvariant()) -and
        ($_.BaseName -match '^\$[A-Fa-f0-9]{8}$')
    })

    if ($AutoCandidates.Count -eq 0) {
        Write-Host ""
        Write-Host "WARNING: No CBX canary file found in $ProfileRoot."
        Write-Host "         The canary-delete step will be skipped."
        Write-Host ""
    } elseif ($AutoCandidates.Count -eq 1) {
        $CanaryPath = $AutoCandidates[0].FullName
        Write-Host "Auto-selected canary: $CanaryPath"
    } else {
        # Multiple candidates — pick the newest (most recently written by CBX).
        $newest = $AutoCandidates | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        Write-Host ""
        Write-Host "Multiple CBX canary candidates found:"
        foreach ($ac in $AutoCandidates) {
            $marker = if ($ac.FullName -eq $newest.FullName) { ' <-- selected (newest)' } else { '' }
            Write-Host "  $($ac.FullName)  [$($ac.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))]$marker"
        }
        Write-Host ""
        $CanaryPath = $newest.FullName
        Write-Host "Auto-selected canary (newest): $CanaryPath"
    }
}


# =====================================================================
# VALIDATE CANARY
# =====================================================================

$FullCanaryPath = $null

if (-not [string]::IsNullOrWhiteSpace($CanaryPath)) {

$FullCanaryPath = [System.IO.Path]::GetFullPath(
    $CanaryPath
)

$CanaryParent = [System.IO.Path]::GetDirectoryName(
    $FullCanaryPath
)


# Require the canary to be directly in the current user's profile.

if (
    -not $CanaryParent.Equals(
        $ProfileRoot.TrimEnd('\'),
        [System.StringComparison]::OrdinalIgnoreCase
    )
) {

    throw (@(
        'CANARY SAFETY CHECK FAILED.',
        '',
        'The selected canary must be directly inside:',
        '',
        "    $ProfileRoot",
        '',
        'Selected:',
        '',
        "    $FullCanaryPath",
        '',
        'No test activity has occurred.'
    ) -join "`r`n")
}


# Expected CBX canary-style filename.

$CanaryBaseName = [System.IO.Path]::GetFileNameWithoutExtension(
    $FullCanaryPath
)

if ($CanaryBaseName -notmatch '^\$[A-Fa-f0-9]{8}$') {

    throw (@(
        'CANARY SAFETY CHECK FAILED.',
        '',
        'Unexpected filename:',
        '',
        "    $CanaryBaseName",
        '',
        'Expected pattern:',
        '',
        '    $XXXXXXXX',
        '',
        'where X is hexadecimal.'
    ) -join "`r`n")
}


$AllowedCanaryExtensions = @(
    '.doc',
    '.docx',
    '.xls',
    '.xlsx',
    '.ppt',
    '.pptx',
    '.jpg',
    '.jpeg'
)

$CanaryExtension = [System.IO.Path]::GetExtension(
    $FullCanaryPath
).ToLowerInvariant()

if ($AllowedCanaryExtensions -notcontains $CanaryExtension) {

    throw (@(
        'CANARY SAFETY CHECK FAILED.',
        '',
        'Unexpected extension:',
        '',
        "    $CanaryExtension"
    ) -join "`r`n")
}


if (-not [System.IO.File]::Exists($FullCanaryPath)) {

    throw (@(
        'Selected canary does not currently exist:',
        '',
        "    $FullCanaryPath",
        '',
        'The CBX agent may have replaced it with a new canary.'
    ) -join "`r`n")
}


$CanaryAttributes = [System.IO.File]::GetAttributes(
    $FullCanaryPath
)

if (
    ($CanaryAttributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0
) {

    throw "Canary path is a reparse point. Test aborted."
}

} # end if (-not [string]::IsNullOrWhiteSpace($CanaryPath))


# =====================================================================
# DISPLAY TEST PLAN
# =====================================================================

$StartTime = [DateTime]::UtcNow

Write-Host ""
Write-Host "============================================================"
Write-Host " CBX COMBINED RANSOMWARE + CANARY TEST"
Write-Host "============================================================"
Write-Host ""
Write-Host "AUTHORIZED SECURITY TESTING ONLY"
Write-Host ""
Write-Host "PowerShell PID      : $PID"
Write-Host "UTC Start           : $($StartTime.ToString('o'))"
Write-Host ""
Write-Host "Synthetic files     : $FileCount"
Write-Host "Canary after file   : $CanaryAfter"
Write-Host "Inter-file delay    : $DelayMs ms"
Write-Host ""
Write-Host "Synthetic sandbox:"
Write-Host "  $RunPath"
Write-Host ""
if ($null -ne $FullCanaryPath) {
    Write-Host "Canary:"
    Write-Host "  $FullCanaryPath"
    Write-Host ""
    Write-Host "The canary will receive exactly ONE operation:"
    Write-Host ""
    Write-Host "  DELETE"
    Write-Host ""
} else {
    Write-Host "Canary:"
    Write-Host "  (none -- canary-delete step will be skipped)"
    Write-Host ""
}
Write-Host "NO encryption will be performed."
Write-Host ""


if (-not $Force) {

    $Response = Read-Host `
        'Type YES to begin the combined test'

    if ($Response -cne 'YES') {

        Write-Host ""
        Write-Host "Test cancelled."
        exit 0
    }
}


# =====================================================================
# ZIP PACKAGE CREATOR
# =====================================================================

function New-ZipPackage {

    param (
        [string]$Path,
        [hashtable]$Entries
    )

    Assert-TestPath $Path | Out-Null

    $FileStream = [System.IO.File]::Open(
        $Path,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
    )

    try {

        $Archive = New-Object System.IO.Compression.ZipArchive(
            $FileStream,
            [System.IO.Compression.ZipArchiveMode]::Create,
            $false
        )

        try {

            foreach ($Name in $Entries.Keys) {

                $Entry = $Archive.CreateEntry(
                    $Name,
                    [System.IO.Compression.CompressionLevel]::Optimal
                )

                $Stream = $Entry.Open()

                try {

                    $Encoding = New-Object `
                        System.Text.UTF8Encoding($false)

                    $Writer = New-Object `
                        System.IO.StreamWriter(
                            $Stream,
                            $Encoding
                        )

                    try {
                        $Writer.Write(
                            [string]$Entries[$Name]
                        )
                    }
                    finally {
                        $Writer.Dispose()
                    }
                }
                finally {
                    $Stream.Dispose()
                }
            }
        }
        finally {
            $Archive.Dispose()
        }
    }
    finally {
        $FileStream.Dispose()
    }
}


# =====================================================================
# CREATE VALID DOCX
# =====================================================================

function New-TestDocx {

    param (
        [string]$Path,
        [int]$Index
    )

    $Text = "Authorized CBX telemetry test document $Index. " * 100

    $Entries = @{

        '[Content_Types].xml' = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml"
 ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>
'@

        '_rels/.rels' = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship
 Id="rId1"
 Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
 Target="word/document.xml"/>
</Relationships>
'@

        'word/document.xml' = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + "`r`n" +
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' + "`r`n" +
            '<w:body>' + "`r`n" +
            '<w:p>' + "`r`n" +
            '<w:r>' + "`r`n" +
            "<w:t>$Text</w:t>" + "`r`n" +
            '</w:r>' + "`r`n" +
            '</w:p>' + "`r`n" +
            '<w:sectPr/>' + "`r`n" +
            '</w:body>' + "`r`n" +
            '</w:document>'
        )
    }

    New-ZipPackage `
        -Path $Path `
        -Entries $Entries
}


# =====================================================================
# CREATE VALID XLSX
# =====================================================================

function New-TestXlsx {

    param (
        [string]$Path,
        [int]$Index
    )

    $Entries = @{

        '[Content_Types].xml' = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml"
 ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml"
 ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>
'@

        '_rels/.rels' = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship
 Id="rId1"
 Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
 Target="xl/workbook.xml"/>
</Relationships>
'@

        'xl/workbook.xml' = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook
 xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>
<sheet name="TelemetryTest" sheetId="1" r:id="rId1"/>
</sheets>
</workbook>
'@

        'xl/_rels/workbook.xml.rels' = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship
 Id="rId1"
 Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
 Target="worksheets/sheet1.xml"/>
</Relationships>
'@

        'xl/worksheets/sheet1.xml' = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + "`r`n" +
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' + "`r`n" +
            '<sheetData>' + "`r`n" +
            '<row r="1">' + "`r`n" +
            '<c r="A1" t="inlineStr">' + "`r`n" +
            "<is><t>Authorized CBX telemetry test $Index</t></is>" + "`r`n" +
            '</c>' + "`r`n" +
            '</row>' + "`r`n" +
            '</sheetData>' + "`r`n" +
            '</worksheet>'
        )
    }

    New-ZipPackage `
        -Path $Path `
        -Entries $Entries
}


# =====================================================================
# CREATE SIMPLE VALID JPEG
# =====================================================================

function New-TestJpeg {

    param (
        [string]$Path,
        [int]$Index
    )

    Assert-TestPath $Path | Out-Null

    $Bitmap = New-Object System.Drawing.Bitmap 640,120
    $Graphics = [System.Drawing.Graphics]::FromImage($Bitmap)

    $Font = New-Object System.Drawing.Font(
        'Arial',
        14
    )

    try {

        $Graphics.Clear(
            [System.Drawing.Color]::White
        )

        $Graphics.DrawString(
            "Authorized CBX telemetry test $Index",
            $Font,
            [System.Drawing.Brushes]::Black,
            20,
            40
        )

        $Bitmap.Save(
            $Path,
            [System.Drawing.Imaging.ImageFormat]::Jpeg
        )
    }
    finally {

        $Font.Dispose()
        $Graphics.Dispose()
        $Bitmap.Dispose()
    }
}


# =====================================================================
# CREATE SIMPLE PDF
# =====================================================================

function New-TestPdf {

    param (
        [string]$Path,
        [int]$Index
    )

    Assert-TestPath $Path | Out-Null

    $Text = (
        '%PDF-1.4' + "`r`n" +
        '1 0 obj' + "`r`n" +
        '<< /Type /Catalog /Pages 2 0 R >>' + "`r`n" +
        'endobj' + "`r`n" +
        '2 0 obj' + "`r`n" +
        '<< /Type /Pages /Count 0 >>' + "`r`n" +
        'endobj' + "`r`n" +
        "% Authorized CBX telemetry test $Index" + "`r`n" +
        '%%EOF'
    )

    [System.IO.File]::WriteAllText(
        $Path,
        $Text,
        [System.Text.Encoding]::ASCII
    )
}


# =====================================================================
# CREATE SANDBOX
# =====================================================================

if (-not (Test-Path -LiteralPath $BasePath)) {

    New-Item `
        -Path $BasePath `
        -ItemType Directory `
        -Force |
        Out-Null
}


if (Test-Path -LiteralPath $RunPath) {

    throw "Unique test directory unexpectedly already exists."
}


New-Item `
    -Path $RunPath `
    -ItemType Directory |
    Out-Null


$Folders = @(
    'Documents',
    'Finance',
    'Projects',
    'Pictures',
    'Archive'
)


foreach ($Folder in $Folders) {

    $FolderPath = Join-Path $RunPath $Folder

    Assert-TestPath $FolderPath | Out-Null

    New-Item `
        -Path $FolderPath `
        -ItemType Directory |
        Out-Null
}


# =====================================================================
# CREATE SYNTHETIC FILE MANIFEST
# =====================================================================

$CreatedFiles = New-Object `
    System.Collections.Generic.List[string]


$Types = @(
    'docx',
    'xlsx',
    'pdf',
    'jpg',
    'txt',
    'csv',
    'zip'
)


Write-Host "[1/4] Creating $FileCount synthetic documents..."


for ($i = 1; $i -le $FileCount; $i++) {

    $Folder = $Folders[
        ($i - 1) % $Folders.Count
    ]

    $Type = $Types[
        ($i - 1) % $Types.Count
    ]

    $Directory = Join-Path $RunPath $Folder

    $FileName = 'TelemetryDocument-{0:D4}.{1}' -f `
        $i,
        $Type

    $Path = Join-Path $Directory $FileName

    Assert-TestPath $Path | Out-Null


    switch ($Type) {

        'docx' {

            New-TestDocx `
                -Path $Path `
                -Index $i
        }

        'xlsx' {

            New-TestXlsx `
                -Path $Path `
                -Index $i
        }

        'jpg' {

            New-TestJpeg `
                -Path $Path `
                -Index $i
        }

        'pdf' {

            New-TestPdf `
                -Path $Path `
                -Index $i
        }

        'txt' {

            [System.IO.File]::WriteAllText(
                $Path,
                ("Authorized CBX test file $i`r`n" * 200),
                [System.Text.Encoding]::UTF8
            )
        }

        'csv' {

            $Csv = "Record,Description,Value`r`n"

            for ($Row = 1; $Row -le 100; $Row++) {

                $Csv += "$Row,CBX Test,$($Row * $i)`r`n"
            }

            [System.IO.File]::WriteAllText(
                $Path,
                $Csv,
                [System.Text.Encoding]::UTF8
            )
        }

        'zip' {

            New-ZipPackage `
                -Path $Path `
                -Entries @{
                    'TelemetryTest.txt' =
                        ("Authorized CBX test archive $i`r`n" * 100)
                }
        }
    }


    $CreatedFiles.Add(
        [System.IO.Path]::GetFullPath($Path)
    )
}


Write-Host "      Created $($CreatedFiles.Count) files."

Start-Sleep -Seconds 2


# =====================================================================
# RANDOM DATA GENERATOR
# =====================================================================

$Random = New-Object `
    System.Security.Cryptography.RNGCryptoServiceProvider


# =====================================================================
# COUNTERS
# =====================================================================

$Processed       = 0
$Renamed         = 0
$Deleted         = 0
$Overwritten     = 0

$CanaryAttempted = $false
$CanaryDeleted   = $false
$CanaryTime      = $null
$CanaryError     = $null


# =====================================================================
# CANARY FUNCTION
# =====================================================================

function Invoke-CanaryInteraction {

    Write-Host ""
    Write-Host "============================================================"
    Write-Host " CANARY INTERACTION"
    Write-Host "============================================================"

    $script:CanaryAttempted = $true
    $script:CanaryTime = [DateTime]::UtcNow

    Write-Host ""
    Write-Host "Synthetic files processed : $Processed"
    Write-Host "PowerShell PID             : $PID"
    Write-Host "UTC                        : $($script:CanaryTime.ToString('o'))"
    Write-Host "Canary                     : $FullCanaryPath"
    Write-Host ""


    # Revalidate immediately before the operation.

    if (-not [System.IO.File]::Exists($FullCanaryPath)) {

        $script:CanaryError = `
            'Canary no longer exists before trigger.'

        Write-Warning $script:CanaryError
        return
    }


    try {

        # EXACTLY ONE operation against the canary.
        #
        # No read.
        # No hash.
        # No overwrite.
        # No rename.
        # No enumeration.

        [System.IO.File]::Delete(
            $FullCanaryPath
        )

        $script:CanaryDeleted = $true

        Write-Host "Canary delete returned successfully."
    }
    catch {

        $script:CanaryError = $_.Exception.Message

        Write-Warning (
            "Canary operation was blocked or failed: {0}" -f `
            $script:CanaryError
        )
    }


    Write-Host ""
    Write-Host "Continuing synthetic workload if process remains alive..."
    Write-Host ""
}


# =====================================================================
# RANSOMWARE-LIKE SYNTHETIC ACTIVITY
# =====================================================================

Write-Host ""
Write-Host "[2/4] Starting ransomware-like synthetic workload..."
Write-Host ""


try {

    foreach ($SourcePath in $CreatedFiles) {

        $SourcePath = Assert-TestPath $SourcePath


        # -------------------------------------------------------------
        # READ ORIGINAL SYNTHETIC DOCUMENT
        # -------------------------------------------------------------

        $OriginalBytes = [System.IO.File]::ReadAllBytes(
            $SourcePath
        )


        # -------------------------------------------------------------
        # CREATE RANDOMIZED HIGH-ENTROPY REPLACEMENT
        #
        # NOT encryption.
        # -------------------------------------------------------------

        $Length = [Math]::Max(
            4096,
            $OriginalBytes.Length
        )

        $Length = [Math]::Min(
            $Length,
            1048576
        )

        $Replacement = New-Object byte[] $Length

        $Random.GetBytes(
            $Replacement
        )


        # -------------------------------------------------------------
        # DIRECT IN-PLACE OVERWRITE
        # -------------------------------------------------------------

        $Stream = New-Object System.IO.FileStream(
            $SourcePath,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Write,
            [System.IO.FileShare]::None
        )

        try {

            $Stream.SetLength(0)

            $Stream.Write(
                $Replacement,
                0,
                $Replacement.Length
            )

            $Stream.Flush($true)
        }
        finally {

            $Stream.Dispose()
        }


        # -------------------------------------------------------------
        # MIXED FILE OUTCOMES
        #
        # 80% rename
        # 15% delete
        #  5% overwrite only
        # -------------------------------------------------------------

        $Selector = $Processed % 20


        if ($Selector -lt 16) {

            $LockedPath = $SourcePath + '.locked'

            Assert-TestPath $LockedPath | Out-Null

            Move-Item `
                -LiteralPath $SourcePath `
                -Destination $LockedPath

            $Renamed++
        }
        elseif ($Selector -lt 19) {

            Assert-TestPath $SourcePath | Out-Null

            Remove-Item `
                -LiteralPath $SourcePath `
                -Force

            $Deleted++
        }
        else {

            $Overwritten++
        }


        $Processed++


        # -------------------------------------------------------------
        # CANARY TRIGGER
        # -------------------------------------------------------------

        if (
            ($null -ne $FullCanaryPath) -and
            (-not $CanaryAttempted) -and
            ($Processed -eq $CanaryAfter)
        ) {

            Invoke-CanaryInteraction
        }


        # -------------------------------------------------------------
        # PROGRESS
        # -------------------------------------------------------------

        if (
            ($Processed % 10 -eq 0) -or
            ($Processed -eq $FileCount)
        ) {

            Write-Host (
                "[{0}] Processed {1}/{2}" -f `
                ([DateTime]::UtcNow.ToString('HH:mm:ss.fff')),
                $Processed,
                $FileCount
            )
        }


        if ($DelayMs -gt 0) {

            Start-Sleep `
                -Milliseconds $DelayMs
        }
    }
}
finally {

    if ($null -ne $Random) {

        $Random.Dispose()
    }
}


# =====================================================================
# BENIGN TEST NOTICE
# =====================================================================

Write-Host ""
Write-Host "[3/4] Writing simulation notice..."


$NoticePath = Join-Path `
    $RunPath `
    'README_SIMULATION.txt'

Assert-TestPath $NoticePath | Out-Null


(@(
    'AUTHORIZED CBX SECURITY TEST',
    '',
    'This directory contains synthetic files generated specifically for',
    'authorized endpoint-security telemetry testing.',
    '',
    'NO actual ransomware was executed.',
    'NO encryption was performed.',
    'NO pre-existing user files were modified.',
    '',
    'Combined test:',
    '',
    "Synthetic file count : $FileCount",
    "Canary trigger after : $CanaryAfter",
    "PowerShell PID       : $PID",
    "UTC start            : $($StartTime.ToString('o'))",
    "UTC canary trigger   : $CanaryTime"
) -join "`r`n") | Set-Content `
    -LiteralPath $NoticePath `
    -Encoding UTF8


# =====================================================================
# SUMMARY
# =====================================================================

Write-Host ""
Write-Host "[4/4] Test complete."
Write-Host ""
Write-Host "============================================================"
Write-Host " RESULTS"
Write-Host "============================================================"
Write-Host ""
Write-Host "PowerShell PID          : $PID"
Write-Host ""
Write-Host "Synthetic processed     : $Processed"
Write-Host "Overwrite + rename      : $Renamed"
Write-Host "Overwrite + delete      : $Deleted"
Write-Host "Overwrite only          : $Overwritten"
Write-Host ""
Write-Host "Canary trigger position : $CanaryAfter"
Write-Host "Canary attempted        : $CanaryAttempted"
Write-Host "Canary delete returned  : $CanaryDeleted"
Write-Host "Canary UTC time         : $CanaryTime"

if ($null -ne $CanaryError) {

    Write-Host "Canary error            : $CanaryError"
}

Write-Host ""
Write-Host "Sandbox:"
Write-Host "  $RunPath"
Write-Host ""
Write-Host "Canary:"
Write-Host "  $FullCanaryPath"
Write-Host ""
Write-Host "NO encryption was performed."
Write-Host "NO existing user documents were modified."

Write-Host ""

} finally {
    if ($stage6TranscriptStarted) { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
}