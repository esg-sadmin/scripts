# ============================================================================
# Stage1-Discovery.ps1
# MITRE: T1082 System Info | T1087.002 Domain Account | T1069.002 Domain Groups
#        T1012 Query Registry | T1016 Network Config | T1057 Process Discovery
# ----------------------------------------------------------------------------
# Fully benign and read-only. Runs the discovery commands an operator issues
# right after landing on a host. Nothing is written or changed, so there is
# no cleanup for this stage.
#
# Maps to guide 7.1 (run scenario) and 7.2 (triage by ATT&CK tactic Discovery).
# ============================================================================
[CmdletBinding()]
param(
    [string]$SkipDiscovery = ''  # comma-separated keys to skip; empty = run all
)

# --- standalone logging if not launched by the runner ---
if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}

Write-Stage "STAGE 1 - DISCOVERY"

function Invoke-Discovery {
    param([string]$Label, [scriptblock]$Command)
    Write-Step $Label
    try { & $Command 2>&1 | Out-Host }
    catch { Write-Info "not available in this environment: $($_.Exception.Message)" }
}

$skip = if ($SkipDiscovery) { $SkipDiscovery -split ',' | ForEach-Object { $_.Trim() } } else { @() }

$allCommands = [ordered]@{
    'systeminfo'       = @{ Label='T1082  systeminfo';                   Cmd={ systeminfo } }
    'tasklist'         = @{ Label='T1057  tasklist';                     Cmd={ tasklist } }
    'ipconfig'         = @{ Label='T1016  ipconfig /all';                Cmd={ ipconfig /all } }
    'arp'              = @{ Label='T1016  arp -a';                       Cmd={ arp -a } }
    'whoami'           = @{ Label='T1033  whoami /all';                  Cmd={ whoami /all } }
    'net_user_local'   = @{ Label='T1087.001 local users';              Cmd={ net user } }
    'net_user_domain'  = @{ Label='T1087.002 domain users';             Cmd={ net user /domain } }
    'net_group_admins' = @{ Label='T1069.002 Domain Admins group';      Cmd={ net group "Domain Admins" /domain } }
    'nltest'           = @{ Label='T1482  domain trusts';                Cmd={ nltest /domain_trusts } }
    'reg_winver'       = @{ Label='T1012  reg query (Windows build)';   Cmd={ reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" } }
    'reg_defender'     = @{ Label='T1518.001 reg query (AV/security)';  Cmd={ reg query "HKLM\SOFTWARE\Microsoft\Windows Defender" } }
}

foreach ($key in $allCommands.Keys) {
    if ($key -notin $skip) {
        Invoke-Discovery $allCommands[$key].Label $allCommands[$key].Cmd
    }
}

Write-StageEnd "STAGE 1 - DISCOVERY"
