<#
.SYNOPSIS
    Symantec CBX controlled canary-file test.

.DESCRIPTION
    AUTHORIZED SECURITY TESTING ONLY.

    The script searches ONLY the current user's profile for filenames
    matching the typical canary pattern and allows deletion of exactly
    ONE explicitly selected candidate.

    It does NOT:
      - Encrypt anything
      - Modify multiple files
      - Traverse outside the current user's profile
      - Touch system files
      - Disable security controls
      - Modify shadow copies
#>

[CmdletBinding()]
param (
    [string]$CanaryPath,
    [switch]$Force
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'


# =====================================================================
# CONFIGURATION
# =====================================================================

$ProfileRoot = [System.IO.Path]::GetFullPath(
    $env:USERPROFILE
)

$ProfilePrefix = $ProfileRoot.TrimEnd('\') + '\'

$AllowedExtensions = @(
    '.doc',
    '.docx',
    '.xls',
    '.xlsx',
    '.ppt',
    '.pptx',
    '.jpg',
    '.jpeg'
)


# =====================================================================
# FIND CANDIDATES
# =====================================================================

Write-Host ""
Write-Host "============================================================"
Write-Host " SYMANTEC CBX CANARY TEST"
Write-Host "============================================================"
Write-Host ""
Write-Host "AUTHORIZED SECURITY TESTING ONLY"
Write-Host ""
Write-Host "Searching ONLY:"
Write-Host "  $ProfileRoot"
Write-Host ""


# Typical canary filenames resemble:
#
#   $XXXXXXXX.doc
#   $XXXXXXXX.xls
#   $XXXXXXXX.jpg
#   $XXXXXXXX.pptx
#
# Search is restricted to the current user's profile.

$Candidates = @(Get-ChildItem `
    -LiteralPath $ProfileRoot `
    -File `
    -Force `
    -Recurse `
    -ErrorAction SilentlyContinue |
Where-Object {

    $Extension = $_.Extension.ToLowerInvariant()

    ($AllowedExtensions -contains $Extension) -and
    ($_.BaseName -match '^\$[A-Fa-f0-9]{8}$')
})


# =====================================================================
# LIST MODE
# =====================================================================

if ([string]::IsNullOrWhiteSpace($CanaryPath)) {

    if ($Candidates.Count -eq 0) {

        Write-Host "No canary-pattern candidates were found."
        Write-Host ""
        Write-Host "No files were modified."

        exit 0
    }


    Write-Host "Potential CBX canary files:"
    Write-Host ""

    $Index = 1

    foreach ($File in $Candidates) {

        Write-Host (
            "[{0}] {1}" -f `
            $Index,
            $File.FullName
        )

        $Index++
    }

    Write-Host ""
    Write-Host "No files were modified."
    Write-Host ""
    Write-Host "Rerun with one exact path:"
    Write-Host ""
    Write-Host "  .\CanaryTest.ps1 -CanaryPath '<path>'"
    Write-Host ""

    exit 0
}


# =====================================================================
# VALIDATE SELECTED PATH
# =====================================================================

$FullCanaryPath = [System.IO.Path]::GetFullPath(
    $CanaryPath
)


# Must remain under current user's profile.

if (
    -not $FullCanaryPath.StartsWith(
        $ProfilePrefix,
        [System.StringComparison]::OrdinalIgnoreCase
    )
) {

    throw (@(
        'SAFETY CHECK FAILED.',
        '',
        'Selected file is outside the current user profile:',
        '',
        "    $FullCanaryPath",
        '',
        'No file was modified.'
    ) -join "`r`n")
}


if (-not (Test-Path -LiteralPath $FullCanaryPath -PathType Leaf)) {

    throw "Selected file does not exist: $FullCanaryPath"
}


$File = Get-Item `
    -LiteralPath $FullCanaryPath `
    -Force


# Reject reparse points.

if (
    ($File.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0
) {

    throw "Selected file is a reparse point. Test aborted."
}


# Extension validation.

$Extension = $File.Extension.ToLowerInvariant()

if ($AllowedExtensions -notcontains $Extension) {

    throw "Unexpected file extension: $Extension"
}


# Filename-pattern validation.

if ($File.BaseName -notmatch '^\$[A-Fa-f0-9]{8}$') {

    throw (@(
        'Selected file does not match the expected canary naming pattern:',
        '',
        "    $($File.Name)",
        '',
        'No file was modified.'
    ) -join "`r`n")
}


# Ensure the explicitly selected path was among our candidates.

$CandidateMatch = $Candidates |
    Where-Object {
        $_.FullName.Equals(
            $FullCanaryPath,
            [System.StringComparison]::OrdinalIgnoreCase
        )
    }


if ($null -eq $CandidateMatch) {

    throw (@(
        "Selected file was not found in this run's canary candidate list.",
        '',
        'No file was modified.'
    ) -join "`r`n")
}


# =====================================================================
# CONFIRM
# =====================================================================

Write-Host ""
Write-Host "Selected candidate:"
Write-Host ""
Write-Host "  $FullCanaryPath"
Write-Host ""
Write-Host "Size:"
Write-Host "  $($File.Length) bytes"
Write-Host ""
Write-Host "The script will DELETE exactly this one file."
Write-Host ""


if (-not $Force) {

    $Response = Read-Host `
        'Type YES to perform the canary test'

    if ($Response -cne 'YES') {

        Write-Host ""
        Write-Host "Cancelled. No file was modified."

        exit 0
    }
}


# =====================================================================
# DELETE ONE CANDIDATE
# =====================================================================

Remove-Item `
    -LiteralPath $FullCanaryPath `
    -Force


Write-Host ""
Write-Host "Test action completed."
Write-Host ""
Write-Host "Targeted exactly one file:"
Write-Host ""
Write-Host "  $FullCanaryPath"
Write-Host ""
Write-Host "No encryption or bulk file modification was performed."