# ============================================================================
# Invoke-RemoteCleanup.ps1
# ----------------------------------------------------------------------------
# Triggers Cleanup-Target2.ps1 on a remote host via WMI (Win32_Process.Create),
# polls until the process exits, then reads the transcript back over SMB so the
# GUI activity log shows the remote output in-line.
#
# Called by the GUI's Cleanup T2 button when a Remote Target is configured.
# Cleanup-Target2.ps1 must already be in C:\Users\Public\staging\ on the remote
# host -- Stage 4 copies it there as part of the kit staging step.
# ============================================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$RemoteTarget,
    [switch]$PromptCredentials,
    [string]$Username,
    [string]$Password
)

if (-not (Get-Command Write-Step -ErrorAction SilentlyContinue)) {
    function Write-Step($m) { Write-Host "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))] $m" -ForegroundColor Yellow }
    function Write-Info($m) { Write-Host "        $m" -ForegroundColor DarkGray }
}

Write-Host "`n==== CLEANUP - TARGET 2 (remote: $RemoteTarget)  START $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))" -ForegroundColor Cyan

# ---- Optional credentials ----
$cred = $null
if ($Username -and $Password) {
    $cred = [PSCredential]::new($Username, (ConvertTo-SecureString $Password -AsPlainText -Force))
} elseif ($PromptCredentials) {
    Write-Info "Enter lab admin credentials for $RemoteTarget"
    $cred = Get-Credential
}

# ---- Remote paths ----
$remoteScript = 'C:\Users\Public\staging\Cleanup-Target2.ps1'
$remoteLog    = 'C:\Users\Public\staging\cleanup-t2-log.txt'

# Wrap with Start-Transcript so Write-Host output is captured to a log file that
# can be read back over SMB after the process exits.
$remoteCmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ' +
             "`"Start-Transcript '$remoteLog' -Force | Out-Null; " +
             "& '$remoteScript'; Stop-Transcript | Out-Null`""

Write-Step "Triggering Cleanup-Target2.ps1 on $RemoteTarget via Win32_Process.Create"

$cimSession = $null
$tmpDrive   = $null
try {
    # ---- CimSession for credential passing (same pattern as Stage 4) ----
    if ($cred) {
        $cimSession = New-CimSession -ComputerName $RemoteTarget -Credential $cred -ErrorAction Stop
    }

    # ---- Launch the remote cleanup process ----
    $cimParams = @{ ClassName = 'Win32_Process'; MethodName = 'Create'
                    Arguments = @{ CommandLine = $remoteCmd } }
    if ($cimSession) { $cimParams['CimSession'] = $cimSession } else { $cimParams['ComputerName'] = $RemoteTarget }
    $result = Invoke-CimMethod @cimParams
    if ($result.ReturnValue -ne 0) {
        throw "Win32_Process.Create returned $($result.ReturnValue) on $RemoteTarget."
    }
    $remotePid = $result.ProcessId
    Write-Step "Remote cleanup process started on $RemoteTarget (PID $remotePid)"
    Write-Info "Polling for process exit (up to 90 s)..."

    # ---- Poll until the process exits ----
    $deadline = (Get-Date).AddSeconds(90)
    do {
        Start-Sleep -Seconds 3
        $pollParams = @{ ClassName = 'Win32_Process'; Filter = "ProcessId=$remotePid" }
        if ($cimSession) { $pollParams['CimSession'] = $cimSession } else { $pollParams['ComputerName'] = $RemoteTarget }
        $running = Get-CimInstance @pollParams -ErrorAction SilentlyContinue
    } while ($null -ne $running -and (Get-Date) -lt $deadline)

    if ($null -ne $running) {
        Write-Warning "Remote process (PID $remotePid) still running after 90 s -- check $remoteLog on $RemoteTarget."
    } else {
        Write-Step "Remote process exited. Reading cleanup log from $RemoteTarget via SMB."

        # ---- Map the admin share to read the log back ----
        if ($cred) {
            $tmpDrive = 'CBXClean'
            New-PSDrive -Name $tmpDrive -PSProvider FileSystem -Root "\\$RemoteTarget\C$" `
                        -Credential $cred -ErrorAction Stop | Out-Null
            $logRef = "${tmpDrive}:\Users\Public\staging\cleanup-t2-log.txt"
        } else {
            $logRef = "\\$RemoteTarget\C$\Users\Public\staging\cleanup-t2-log.txt"
        }

        if (Test-Path $logRef) {
            Write-Host ""
            Get-Content $logRef
        } else {
            Write-Warning "Cleanup log not found at $logRef -- remote script may not have written one."
        }
    }
} catch {
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    throw
} finally {
    if ($tmpDrive)   { Remove-PSDrive   -Name $tmpDrive -Force -ErrorAction SilentlyContinue }
    if ($cimSession) { Remove-CimSession $cimSession           -ErrorAction SilentlyContinue }
}

Write-Host "==== CLEANUP - TARGET 2 (remote: $RemoteTarget)  END   $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'))`n" -ForegroundColor Cyan
