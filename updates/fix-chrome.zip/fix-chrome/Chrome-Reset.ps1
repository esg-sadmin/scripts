# ============================================================================
# CBX-Emulation-GUI.ps1
# WPF launcher for the CBX Staged Emulation Kit  v1.6
# ============================================================================
# Launch from an elevated PowerShell session in the kit directory:
#     .\CBX-Emulation-GUI.ps1
# Or use Run-GUI.cmd (prefers PowerShell 7 if installed).
#
# v1.2 changes:
#   * Direct-action buttons (Setup / Run / Cleanup) -- no separate Launch step.
#   * Single command builder drives both the preview and the run (no drift).
#   * Confirmation on destructive actions (Visibility chain, Stage 4/6, Cleanups).
#   * Stage info chip, Copy command, Save log, Relaunch-as-admin.
#   * Numeric fields validated inline against each script's valid range.
#   * Action buttons disable while a run is in progress; reader runspaces disposed.
#
# Output from each action streams directly into the Activity Log.
# Stage 6 is run with -Force (the GUI is non-interactive); it still confirms first.
# ============================================================================
[CmdletBinding()] param()

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$script:Version             = 'v1.6'
$script:Dir                 = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:SelfPath            = if ($PSCommandPath) { $PSCommandPath } else { Join-Path $script:Dir 'CBX-Emulation-GUI.ps1' }
$script:OutputQueue         = [System.Collections.Concurrent.ConcurrentQueue[string]]::new()

# Active reader handles for the current run (one run at a time; buttons disable while running).
$script:RsOut = $null; $script:PsOut = $null
$script:RsErr = $null; $script:PsErr = $null

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    ([Security.Principal.WindowsPrincipal]$id).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ─── XAML ────────────────────────────────────────────────────────────────────
[xml]$xaml = @'
<Window
  xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
  xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
  Title="CBX Staged Emulation Kit v1.6 &#x2014; POC Runner"
  Width="920" MinWidth="880"
  Height="860" MinHeight="640"
  WindowStartupLocation="CenterScreen"
  Background="#F4F5F7"
  Foreground="#000000"
  FontFamily="Segoe UI"
  FontSize="13"
  SnapsToDevicePixels="True">

  <Window.Resources>

    <!-- ── Color brushes (ESG Brand palette) ── -->
    <SolidColorBrush x:Key="bNavy"      Color="#01234D"/>
    <SolidColorBrush x:Key="bBlue"      Color="#005C8A"/>
    <SolidColorBrush x:Key="bLightBlue" Color="#0098C7"/>
    <SolidColorBrush x:Key="bAqua"      Color="#619AB7"/>
    <SolidColorBrush x:Key="bDarkBlue"  Color="#1B1D36"/>
    <SolidColorBrush x:Key="bYellow"    Color="#F3BA16"/>
    <SolidColorBrush x:Key="bMerlot"    Color="#961D49"/>
    <SolidColorBrush x:Key="bDarkGray"  Color="#5A5A5A"/>
    <SolidColorBrush x:Key="bGray100"   Color="#F4F5F7"/>
    <SolidColorBrush x:Key="bGray200"   Color="#E6E8EB"/>
    <SolidColorBrush x:Key="bGray300"   Color="#CFD3D8"/>
    <SolidColorBrush x:Key="bWhite"     Color="#FFFFFF"/>

    <!-- ── TextBox ── -->
    <Style TargetType="TextBox">
      <Setter Property="Background"                Value="#FFFFFF"/>
      <Setter Property="Foreground"                Value="#000000"/>
      <Setter Property="BorderBrush"               Value="{StaticResource bGray300}"/>
      <Setter Property="BorderThickness"           Value="1"/>
      <Setter Property="Padding"                   Value="6,4"/>
      <Setter Property="Height"                    Value="28"/>
      <Setter Property="VerticalContentAlignment"  Value="Center"/>
    </Style>

    <!-- ── TextBox with watermark (shows Tag text when empty) ── -->
    <Style x:Key="WmTextBox" TargetType="TextBox">
      <Setter Property="Background"      Value="#FFFFFF"/>
      <Setter Property="Foreground"      Value="#000000"/>
      <Setter Property="BorderBrush"     Value="{StaticResource bGray300}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding"         Value="6,4"/>
      <Setter Property="MinHeight"       Value="28"/>
      <Setter Property="TextWrapping"    Value="Wrap"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TextBox">
            <Border Background="{TemplateBinding Background}"
                    BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}">
              <Grid>
                <ScrollViewer x:Name="PART_ContentHost"
                              Margin="{TemplateBinding Padding}"
                              VerticalAlignment="Top"/>
                <TextBlock x:Name="wm" Text="{TemplateBinding Tag}"
                           Margin="8,5,0,0" VerticalAlignment="Top"
                           Foreground="#9AA3AD" IsHitTestVisible="False"
                           TextWrapping="Wrap"
                           Visibility="Collapsed"/>
              </Grid>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="Text" Value="">
                <Setter TargetName="wm" Property="Visibility" Value="Visible"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="WmPasswordBox" TargetType="PasswordBox">
      <Setter Property="Background"      Value="#FFFFFF"/>
      <Setter Property="Foreground"      Value="#000000"/>
      <Setter Property="BorderBrush"     Value="{StaticResource bGray300}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding"         Value="6,4"/>
      <Setter Property="MinHeight"       Value="28"/>
    </Style>

    <!-- ── ComboBox ── -->
    <Style TargetType="ComboBox">
      <Setter Property="Background"    Value="#FFFFFF"/>
      <Setter Property="Foreground"    Value="#000000"/>
      <Setter Property="BorderBrush"   Value="{StaticResource bGray300}"/>
      <Setter Property="Height"        Value="28"/>
      <Setter Property="Padding"       Value="6,4"/>
    </Style>

    <!-- ── CheckBox ── -->
    <Style TargetType="CheckBox">
      <Setter Property="Foreground"               Value="#000000"/>
      <Setter Property="VerticalContentAlignment" Value="Center"/>
      <Setter Property="Margin"                   Value="0,3,0,3"/>
    </Style>

    <!-- ── RadioButton ── -->
    <Style TargetType="RadioButton">
      <Setter Property="Foreground"               Value="#000000"/>
      <Setter Property="VerticalContentAlignment" Value="Center"/>
      <Setter Property="Margin"                   Value="0,4,0,4"/>
    </Style>

    <!-- ── Default button ── -->
    <Style TargetType="Button">
      <Setter Property="Background"      Value="#E6E8EB"/>
      <Setter Property="Foreground"      Value="#000000"/>
      <Setter Property="BorderBrush"     Value="{StaticResource bGray300}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding"         Value="16,6"/>
      <Setter Property="Height"          Value="32"/>
      <Setter Property="MinWidth"        Value="80"/>
      <Setter Property="Cursor"          Value="Hand"/>
    </Style>

    <!-- ── Primary (Run) button ── -->
    <Style x:Key="RunButton" TargetType="Button">
      <Setter Property="Background"      Value="#005C8A"/>
      <Setter Property="Foreground"      Value="#FFFFFF"/>
      <Setter Property="BorderBrush"     Value="#005C8A"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding"         Value="18,6"/>
      <Setter Property="Height"          Value="32"/>
      <Setter Property="MinWidth"        Value="96"/>
      <Setter Property="FontWeight"      Value="SemiBold"/>
      <Setter Property="Cursor"          Value="Hand"/>
    </Style>

    <!-- ── Small utility button ── -->
    <Style x:Key="MiniButton" TargetType="Button">
      <Setter Property="Background"      Value="#E6E8EB"/>
      <Setter Property="Foreground"      Value="#000000"/>
      <Setter Property="BorderBrush"     Value="{StaticResource bGray300}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding"         Value="10,4"/>
      <Setter Property="Height"          Value="28"/>
      <Setter Property="MinWidth"        Value="64"/>
      <Setter Property="FontSize"        Value="12"/>
      <Setter Property="Cursor"          Value="Hand"/>
    </Style>

    <!-- ── Destructive (Cleanup) button : brand merlot ── -->
    <Style x:Key="DangerButton" TargetType="Button">
      <Setter Property="Background"      Value="#FFFFFF"/>
      <Setter Property="Foreground"      Value="#961D49"/>
      <Setter Property="BorderBrush"     Value="#961D49"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding"         Value="16,6"/>
      <Setter Property="Height"          Value="32"/>
      <Setter Property="MinWidth"        Value="80"/>
      <Setter Property="FontWeight"      Value="SemiBold"/>
      <Setter Property="Cursor"          Value="Hand"/>
    </Style>

    <!-- ── Dim label ── -->
    <Style x:Key="DimLbl" TargetType="TextBlock">
      <Setter Property="Foreground"        Value="#5A5A5A"/>
      <Setter Property="VerticalAlignment" Value="Center"/>
      <Setter Property="Margin"            Value="0,0,8,0"/>
      <Setter Property="FontSize"          Value="12"/>
    </Style>

    <!-- ── Section header ── -->
    <Style x:Key="SecHead" TargetType="TextBlock">
      <Setter Property="Foreground"  Value="#005C8A"/>
      <Setter Property="FontWeight"  Value="SemiBold"/>
      <Setter Property="FontSize"    Value="11"/>
      <Setter Property="Margin"      Value="0,0,0,8"/>
    </Style>

    <!-- ── Divider ── -->
    <Style x:Key="HR" TargetType="Rectangle">
      <Setter Property="Height"  Value="1"/>
      <Setter Property="Fill"    Value="{StaticResource bGray200}"/>
      <Setter Property="Margin"  Value="0,6,0,8"/>
    </Style>

  </Window.Resources>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <Grid>
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>   <!-- r0  header         -->
      <RowDefinition Height="3*" MinHeight="300"/> <!-- configuration + actions -->
      <RowDefinition Height="8"/>                  <!-- resize handle -->
      <RowDefinition Height="2*" MinHeight="150"/> <!-- activity log -->
    </Grid.RowDefinitions>

    <!-- ══ HEADER ══════════════════════════════════════════════════════════ -->
    <Border Grid.Row="0" Background="{StaticResource bNavy}" Padding="16,10,16,10">
      <Grid>
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>
        <StackPanel Grid.Column="0">
          <TextBlock Text="CBX Staged Emulation Kit"
                     FontSize="16" FontWeight="Bold" Foreground="White"/>
          <TextBlock FontSize="11" Foreground="{StaticResource bAqua}" Margin="0,2,0,0">
            <Run x:Name="runVersion" Text="v1.6"/>
            <Run Text="  &#xB7;  POC Runner"/>
            <Run Text="  &#xB7;  Isolated, snapshotted lab hosts only"/>
          </TextBlock>
        </StackPanel>
        <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
          <TextBlock x:Name="lblAdmin" VerticalAlignment="Center"
                     FontSize="11" Foreground="{StaticResource bAqua}"
                     Text="Checking&#x2026;" Margin="0,0,10,0"/>
          <Button x:Name="btnElevate" Content="Relaunch as admin"
                  Style="{StaticResource MiniButton}" Visibility="Collapsed"
                  ToolTip="Restart this GUI in an elevated PowerShell session"/>
        </StackPanel>
      </Grid>
    </Border>

    <!-- ══ OPTIONS ══════════════════════════════════════════════════════════ -->
    <Grid Grid.Row="1">
      <Grid.RowDefinitions>
        <RowDefinition Height="*" MinHeight="100"/>
        <RowDefinition Height="Auto"/>
      </Grid.RowDefinitions>
    <Grid Grid.Row="0" Margin="12,10,12,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="1.55*"/>
        <ColumnDefinition Width="8"/>
        <ColumnDefinition Width="*"/>
      </Grid.ColumnDefinitions>

      <!-- ── LEFT: Run Mode panel ── -->
      <Border Grid.Column="0" Background="White"
              BorderBrush="{StaticResource bGray300}" BorderThickness="1"
              CornerRadius="4" Padding="12,10">
        <ScrollViewer x:Name="optScroll" VerticalScrollBarVisibility="Auto"
                      HorizontalScrollBarVisibility="Disabled" Padding="0,0,8,0">
      <ScrollViewer.Resources>
        <!-- Prominent scrollbar so it is obvious the options area scrolls -->
        <Style x:Key="OptScrollThumb" TargetType="Thumb">
          <Setter Property="Template">
            <Setter.Value>
              <ControlTemplate TargetType="Thumb">
                <Border Background="#7E92A6" CornerRadius="4" Margin="2,1,2,1"/>
              </ControlTemplate>
            </Setter.Value>
          </Setter>
        </Style>
        <Style TargetType="ScrollBar">
          <Setter Property="Width"      Value="13"/>
          <Setter Property="Background" Value="#E3E6EA"/>
          <Setter Property="Template">
            <Setter.Value>
              <ControlTemplate TargetType="ScrollBar">
                <Grid Background="{TemplateBinding Background}">
                  <Track x:Name="PART_Track" IsDirectionReversed="True">
                    <Track.DecreaseRepeatButton>
                      <RepeatButton Command="ScrollBar.PageUpCommand" Focusable="False">
                        <RepeatButton.Template>
                          <ControlTemplate TargetType="RepeatButton"><Border Background="Transparent"/></ControlTemplate>
                        </RepeatButton.Template>
                      </RepeatButton>
                    </Track.DecreaseRepeatButton>
                    <Track.IncreaseRepeatButton>
                      <RepeatButton Command="ScrollBar.PageDownCommand" Focusable="False">
                        <RepeatButton.Template>
                          <ControlTemplate TargetType="RepeatButton"><Border Background="Transparent"/></ControlTemplate>
                        </RepeatButton.Template>
                      </RepeatButton>
                    </Track.IncreaseRepeatButton>
                    <Track.Thumb>
                      <Thumb Style="{StaticResource OptScrollThumb}"/>
                    </Track.Thumb>
                  </Track>
                </Grid>
              </ControlTemplate>
            </Setter.Value>
          </Setter>
        </Style>
      </ScrollViewer.Resources>
        <StackPanel>
          <TextBlock Style="{StaticResource SecHead}" Text="RUN MODE"/>

          <RadioButton x:Name="rbPrevention"  IsChecked="True"
            Content="Prevention Profile &#x2014; Section 6, block mode"
            ToolTip="Run only the Section 6 block-mode checks -- benign, single-technique."/>
          <RadioButton x:Name="rbVisibility"
            Content="Visibility Profile &#x2014; Sections 7 &#xB7; 8 &#xB7; 10, monitor mode"
            ToolTip="Run the full staged chain (stages 1-6) in monitor mode for detection coverage."/>
          <RadioButton x:Name="rbSingleStage"
            Content="Single Stage"
            ToolTip="Run one stage on its own (Stage 4 also chains 5 and 6)."/>

          <!-- ── Single Stage selector ── -->
          <StackPanel x:Name="pnlStageSelect" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <Grid>
              <Grid.ColumnDefinitions>
                <ColumnDefinition Width="48"/>
                <ColumnDefinition Width="*"/>
              </Grid.ColumnDefinitions>
              <TextBlock Grid.Column="0" Style="{StaticResource DimLbl}" Text="Stage"/>
              <ComboBox  Grid.Column="1" x:Name="cmbStage"
                         ToolTip="Choose which stage to run by itself."/>
            </Grid>
            <!-- Stage info chip -->
            <Border x:Name="pnlStageChip" Visibility="Collapsed"
                    BorderBrush="{StaticResource bLightBlue}" BorderThickness="2,0,0,0"
                    Margin="0,6,0,0" Padding="8,2,0,2">
              <TextBlock x:Name="lblStageChip" TextWrapping="Wrap" FontSize="11"
                         Foreground="{StaticResource bDarkGray}"/>
            </Border>
          </StackPanel>

          <!-- ── Stage 1 : Discovery (collapsible; 11 commands in 2 columns) ── -->
          <StackPanel x:Name="pnlS1Config" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <Expander IsExpanded="False">
              <Expander.Header>
                <StackPanel Margin="4,0,0,0">
                  <TextBlock Text="STAGE 1 : DISCOVERY COMMANDS"
                             Foreground="#005C8A" FontWeight="SemiBold" FontSize="11"/>
                  <TextBlock Text="Uncheck to skip. All checked = no -SkipDiscovery arg added."
                             FontSize="11" Foreground="{StaticResource bDarkGray}" Margin="0,2,0,0"/>
                </StackPanel>
              </Expander.Header>
              <UniformGrid Columns="2" Margin="4,4,0,0">
                <CheckBox x:Name="chkS1_systeminfo"       IsChecked="True" Content="systeminfo  (T1082)"              ToolTip="OS, patch and hardware inventory (T1082)."/>
                <CheckBox x:Name="chkS1_tasklist"         IsChecked="True" Content="tasklist  (T1057)"                ToolTip="Running processes (T1057)."/>
                <CheckBox x:Name="chkS1_ipconfig"         IsChecked="True" Content="ipconfig /all  (T1016)"           ToolTip="Full network configuration and DNS (T1016)."/>
                <CheckBox x:Name="chkS1_arp"              IsChecked="True" Content="arp -a  (T1016)"                  ToolTip="ARP cache - local network neighbors (T1016)."/>
                <CheckBox x:Name="chkS1_whoami"           IsChecked="True" Content="whoami /all  (T1033)"             ToolTip="Current user, groups and privileges (T1033)."/>
                <CheckBox x:Name="chkS1_net_user_local"   IsChecked="True" Content="net user - local  (T1087.001)"    ToolTip="Local user accounts (T1087.001)."/>
                <CheckBox x:Name="chkS1_net_user_domain"  IsChecked="True" Content="net user /domain  (T1087.002)"    ToolTip="Domain user accounts (T1087.002)."/>
                <CheckBox x:Name="chkS1_net_group_admins" IsChecked="True" Content="net group Domain Admins  (T1069.002)" ToolTip="Domain Admins group membership (T1069.002)."/>
                <CheckBox x:Name="chkS1_nltest"           IsChecked="True" Content="nltest /domain_trusts  (T1482)"   ToolTip="Domain trust relationships (T1482)."/>
                <CheckBox x:Name="chkS1_reg_winver"       IsChecked="True" Content="reg query - Win build  (T1012)"   ToolTip="Windows build from the registry (T1012)."/>
                <CheckBox x:Name="chkS1_reg_defender"     IsChecked="True" Content="reg query - Defender  (T1518.001)" ToolTip="Windows Defender status from the registry (T1518.001)."/>
              </UniformGrid>
            </Expander>
          </StackPanel>

          <!-- ── Stage 2 : Credential Access variant ── -->
          <StackPanel x:Name="pnlS2Config" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <Expander IsExpanded="True">
              <Expander.Header>
                <StackPanel Margin="4,0,0,0">
                  <TextBlock Text="STAGE 2 : CREDENTIAL ACCESS"
                             Foreground="#005C8A" FontWeight="SemiBold" FontSize="11"/>
                  <TextBlock Text="Pick how LSASS is dumped. WebDownload also fires a Web Security event (T1105) so Threat Tracer gets a chained root node."
                             FontSize="11" Foreground="{StaticResource bDarkGray}" TextWrapping="Wrap" Margin="0,2,0,0"/>
                </StackPanel>
              </Expander.Header>
              <StackPanel Margin="4,4,0,0">
                <RadioButton x:Name="rbS2Standard" GroupName="s2variant" IsChecked="True"
                             Content="Standard  &#x2014;  comsvcs.dll MiniDump  (T1003.001)"
                             ToolTip="Runs modules\Stage2-CredentialAccess.ps1 -- endpoint-only LSASS MiniDump via comsvcs.dll. Default."/>
                <RadioButton x:Name="rbS2WebDownload" GroupName="s2variant"
                             Content="WebDownload + Process Dump  &#x2014;  fetch ProcDump, then dump winlogon.exe  (T1105 + T1003)"
                             ToolTip="Runs modules\Stage2b-WebDownloadCredAccess.ps1 -- downloads ProcDump from a 3rd-party URL and dumps winlogon.exe memory (lsass.exe would be blocked on PPL-protected hosts). Fires Web Security + endpoint, chains in Threat Tracer."/>
              </StackPanel>
            </Expander>
          </StackPanel>

          <!-- ── Stage 3 : Persistence ── -->
          <StackPanel x:Name="pnlS3Config" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <Expander IsExpanded="True">
              <Expander.Header>
                <TextBlock Text="STAGE 3 : PERSISTENCE" Margin="4,0,0,0"
                           Foreground="#005C8A" FontWeight="SemiBold" FontSize="11"/>
              </Expander.Header>
              <StackPanel Margin="4,4,0,0">
                <CheckBox x:Name="chkDropMasquerade" IsChecked="False"
                          Content="Drop masquerade copy  ms_teams.exe  (T1036.005)"
                          ToolTip="Drops a renamed copy of powershell.exe as ms_teams.exe into C:\Users\Public -- adds a T1036.005 Masquerading artifact to the investigation graph."/>
              </StackPanel>
            </Expander>
          </StackPanel>

          <!-- ── Stage 4 : Lateral Movement (remote target + credentials) ── -->
          <StackPanel x:Name="pnlVisOpts" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <Expander IsExpanded="True">
              <Expander.Header>
                <TextBlock Text="STAGE 4 : LATERAL MOVEMENT" Margin="4,0,0,0"
                           Foreground="#005C8A" FontWeight="SemiBold" FontSize="11"/>
              </Expander.Header>
              <StackPanel Margin="4,4,0,0">
                <Grid>
                  <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="100"/>
                    <ColumnDefinition Width="*"/>
                  </Grid.ColumnDefinitions>
                  <TextBlock Grid.Column="0" Style="{StaticResource DimLbl}" Text="Remote Target"
                             VerticalAlignment="Center"/>
                  <TextBox Grid.Column="1" x:Name="txtRemoteTarget"
                           Style="{StaticResource WmTextBox}" Tag="LAB-WIN2 (blank = local simulation)"
                           ToolTip="Hostname or IP of the second lab host for the Stage 4 cross-device graph. Blank = local simulation."/>
                </Grid>
                <CheckBox x:Name="chkLocalSim" Margin="0,5,0,0"
                          Content="Local Simulation  (no cross-device graph, overrides Remote Target)"
                          ToolTip="Run Stage 4 locally with no cross-device graph; overrides Remote Target."/>
                <TextBlock Style="{StaticResource DimLbl}" Text="Credentials" Margin="0,9,0,3"/>
                <RadioButton x:Name="rbCredSession" GroupName="creds" IsChecked="True"
                             Content="Use current session"
                             ToolTip="Run Stage 4 as the current logged-in session; no credentials passed."/>
                <RadioButton x:Name="rbCredPrompt" GroupName="creds"
                             Content="Prompt at runtime  (-PromptCredentials)"
                             ToolTip="Prompt for credentials at runtime via Get-Credential."/>
                <RadioButton x:Name="rbCredEnter" GroupName="creds"
                             Content="Enter now  (unattended)"
                             ToolTip="Enter credentials now for a fully unattended run."/>
                <StackPanel x:Name="pnlCredFields" Visibility="Collapsed" Margin="0,4,0,0">
                  <Grid>
                    <Grid.RowDefinitions>
                      <RowDefinition Height="Auto"/>
                      <RowDefinition Height="Auto"/>
                    </Grid.RowDefinitions>
                    <Grid.ColumnDefinitions>
                      <ColumnDefinition Width="100"/>
                      <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Grid.Row="0" Grid.Column="0" Style="{StaticResource DimLbl}"
                               Text="Username" VerticalAlignment="Center" Margin="0,0,8,2"/>
                    <TextBox Grid.Row="0" Grid.Column="1" x:Name="txtUsername"
                             Style="{StaticResource WmTextBox}" Tag="domain\user or user@domain.com"
                             Margin="0,0,0,2"
                             ToolTip="Lateral-movement username. With Password set, the run is fully unattended."/>
                    <TextBlock Grid.Row="1" Grid.Column="0" Style="{StaticResource DimLbl}"
                               Text="Password" VerticalAlignment="Center"/>
                    <Grid Grid.Row="1" Grid.Column="1">
                      <PasswordBox x:Name="pwdPassword" Style="{StaticResource WmPasswordBox}"
                                   ToolTip="Lateral-movement password; plain text to the script -- isolated lab use only."/>
                      <TextBlock x:Name="pwdWatermark" Text="lab password" IsHitTestVisible="False"
                                 Foreground="#9AA3AD" Margin="8,0,0,0" VerticalAlignment="Center"/>
                    </Grid>
                  </Grid>
                  <TextBlock TextWrapping="Wrap" FontSize="11" Margin="0,6,0,0" Foreground="#8A5A00"
                             Text="[!] Unattended mode sends the password in CLEAR TEXT (command line + Activity Log). This is intentional: CBX detects the credential exposure and the investigation flags the account compromised (recommends disable / reset). Use a disposable lab test account."/>
                </StackPanel>
              </StackPanel>
            </Expander>
          </StackPanel>

          <!-- ── Stage 6 : Impact / Canary (moved from the right column) ── -->
          <StackPanel x:Name="pnlImpact" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <Expander IsExpanded="True">
              <Expander.Header>
                <TextBlock x:Name="lblImpactHead" Text="STAGE 6 : IMPACT / CANARY" Margin="4,0,0,0"
                           Foreground="#005C8A" FontWeight="SemiBold" FontSize="11"/>
              </Expander.Header>
              <StackPanel Margin="4,4,0,0">
                <Grid Margin="0,0,0,2">
                  <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="100"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                  </Grid.ColumnDefinitions>
                  <TextBlock Grid.Column="0" Style="{StaticResource DimLbl}" Text="Canary Path"
                             VerticalAlignment="Center"/>
                  <TextBox Grid.Column="1" x:Name="txtCanaryPath"
                           Style="{StaticResource WmTextBox}" Tag="blank = auto-detect $XXXXXXXX.ext in %USERPROFILE%"
                           ToolTip="Path to the CBX canary file. Blank = auto-detect $XXXXXXXX.ext in %USERPROFILE%."/>
                  <Button Grid.Column="2" x:Name="btnBrowseCanary" Content="_Browse..."
                          Padding="8,3" MinWidth="70" Margin="4,0,0,0"
                          VerticalAlignment="Center" ToolTip="Browse for canary file"/>
                </Grid>
                <TextBlock x:Name="lblS6Note" Visibility="Collapsed" TextWrapping="Wrap"
                           Text="Advanced tuning (file count, rate) is available in Single Stage 6; the chain uses blessed defaults."
                           FontStyle="Italic" FontSize="11" Foreground="{StaticResource bDarkGray}"
                           Margin="0,2,0,0"/>
                <StackPanel x:Name="pnlS6Opts" Visibility="Collapsed">
                  <Rectangle Style="{StaticResource HR}"/>
                  <Grid>
                    <Grid.RowDefinitions>
                      <RowDefinition Height="Auto"/>
                      <RowDefinition Height="Auto"/>
                      <RowDefinition Height="Auto"/>
                      <RowDefinition Height="Auto"/>
                    </Grid.RowDefinitions>
                    <Grid.ColumnDefinitions>
                      <ColumnDefinition Width="100"/>
                      <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Grid.Row="0" Grid.Column="0" Style="{StaticResource DimLbl}"
                               Text="File Count" Margin="0,0,8,6"/>
                    <StackPanel Grid.Row="0" Grid.Column="1" Margin="0,0,0,6">
                    <TextBox x:Name="txtFileCount" Text="200"
                             Margin="0,0,0,2" ToolTip="Synthetic files to create (20-500). Default: 200"/>
                      <TextBlock x:Name="txtFileCountHint" Text="20-500 synthetic files" FontSize="11" Foreground="#5A5A5A" TextWrapping="Wrap"/>
                    </StackPanel>
                    <TextBlock Grid.Row="1" Grid.Column="0" Style="{StaticResource DimLbl}"
                               Text="Canary After" Margin="0,0,8,6"/>
                    <StackPanel Grid.Row="1" Grid.Column="1" Margin="0,0,0,6">
                    <TextBox x:Name="txtCanaryAfter" Text="50"
                             Margin="0,0,0,2" ToolTip="Delete canary after N files; must be less than File Count. Default: 50"/>
                      <TextBlock x:Name="txtCanaryAfterHint" Text="1-499; less than File Count" FontSize="11" Foreground="#5A5A5A" TextWrapping="Wrap"/>
                    </StackPanel>
                    <TextBlock Grid.Row="2" Grid.Column="0" Style="{StaticResource DimLbl}"
                               Text="Delay (ms)" Margin="0,0,8,6"/>
                    <StackPanel Grid.Row="2" Grid.Column="1" Margin="0,0,0,6">
                    <TextBox x:Name="txtDelayMs" Text="0"
                             Margin="0,0,0,2" ToolTip="Inter-file delay in ms (0-5000). Default: 0"/>
                      <TextBlock x:Name="txtDelayMsHint" Text="0-5000 milliseconds" FontSize="11" Foreground="#5A5A5A" TextWrapping="Wrap"/>
                    </StackPanel>
                    <TextBlock Grid.Row="3" Grid.Column="0" Grid.ColumnSpan="2" TextWrapping="Wrap"
                               FontSize="11" Foreground="{StaticResource bDarkGray}"
                               Text="The GUI asks for confirmation before running. Stage 6 then runs without another prompt."/>
                  </Grid>
                </StackPanel>
              </StackPanel>
            </Expander>
          </StackPanel>

          <!-- ── GLOBAL : run-wide options ── -->
          <StackPanel x:Name="pnlPause" Visibility="Collapsed">
            <Rectangle Style="{StaticResource HR}"/>
            <TextBlock Style="{StaticResource SecHead}" Text="GLOBAL"/>
            <Grid>
              <Grid.ColumnDefinitions>
                <ColumnDefinition Width="90"/>
                <ColumnDefinition Width="56"/>
                <ColumnDefinition Width="*"/>
              </Grid.ColumnDefinitions>
              <TextBlock Grid.Column="0" Style="{StaticResource DimLbl}" Text="Stage Pause"
                         VerticalAlignment="Center"/>
              <StackPanel Grid.Column="1" Grid.ColumnSpan="2">
                <TextBox x:Name="txtPauseSeconds" Text="0" Width="80" HorizontalAlignment="Left"
                         ToolTip="Seconds to pause between stages (0-86400). 0 = no pause."/>
                <TextBlock x:Name="txtPauseSecondsHint" Text="0-86400 seconds; 0 = no pause" FontSize="11" Foreground="#5A5A5A" TextWrapping="Wrap"/>
              </StackPanel>
            </Grid>
          </StackPanel>
        </StackPanel>
        </ScrollViewer>
      </Border>

      <!-- ── RIGHT: independently scrollable stage details ── -->
      <Border Grid.Column="2"
              Background="White"
              BorderBrush="{StaticResource bGray300}" BorderThickness="1"
              CornerRadius="4" Padding="12,10">
        <DockPanel>
          <TextBlock DockPanel.Dock="Top" Style="{StaticResource SecHead}" Text="WHAT WILL RUN"/>
          <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled">
          <Border Background="{StaticResource bGray100}" Padding="10,9" Margin="0,0,0,2" CornerRadius="3">
            <StackPanel x:Name="pnlWWR"/>
          </Border>
          </ScrollViewer>
        </DockPanel>
      </Border>

    </Grid>

    <!-- ══ COMMAND PREVIEW + BUTTONS ════════════════════════════════════════ -->
    <StackPanel Grid.Row="1" Margin="12,8,12,0">
      <Border Background="White" BorderBrush="{StaticResource bBlue}" BorderThickness="3,0,0,0" Padding="8,4" Margin="0,0,0,6">
        <StackPanel>
          <TextBlock x:Name="lblRunMode" FontWeight="SemiBold" FontSize="12"/>
          <TextBlock x:Name="lblRunTarget" FontSize="12" TextTrimming="CharacterEllipsis"/>
          <TextBlock x:Name="lblRunImpact" FontSize="11" Foreground="{StaticResource bMerlot}" TextWrapping="Wrap"/>
          <TextBlock x:Name="lblValidation" FontSize="11" Foreground="{StaticResource bMerlot}"
                     Text="Correct the highlighted options before running." Visibility="Collapsed"/>
        </StackPanel>
      </Border>

      <!-- Collapsible command preview; bounded so long commands cannot hide the log. -->
      <Border Background="White" BorderBrush="{StaticResource bGray300}"
              BorderThickness="1" CornerRadius="4" Padding="10,5">
        <Expander x:Name="expCommand" IsExpanded="False" Header="Command preview" FontSize="12">
        <Grid Margin="0,4,0,0">
          <Grid.ColumnDefinitions>
            <ColumnDefinition Width="*"/>
            <ColumnDefinition Width="Auto"/>
          </Grid.ColumnDefinitions>
          <StackPanel Grid.Column="0">
            <TextBlock Text="This is exactly what the Run button executes."
                       FontSize="11" Foreground="{StaticResource bDarkGray}" Margin="0,0,0,4"/>
            <TextBox x:Name="txtCommand" IsReadOnly="True"
                     FontFamily="Consolas" FontSize="11"
                     Background="{StaticResource bGray100}" Foreground="#005C8A"
                     BorderThickness="0"
                     TextWrapping="Wrap"
                     MinHeight="26" Height="Auto" MaxHeight="64"
                     VerticalScrollBarVisibility="Auto" Padding="4,3"/>
          </StackPanel>
          <Button Grid.Column="1" x:Name="btnCopyCmd" Content="C_opy"
                  Style="{StaticResource MiniButton}" VerticalAlignment="Bottom"
                  Margin="8,0,0,0" ToolTip="Copy the command to the clipboard"/>
        </Grid>
        </Expander>
      </Border>

      <!-- Action buttons -->
      <Grid Margin="0,8,0,0">
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>
        <WrapPanel Grid.Column="0" Orientation="Horizontal" VerticalAlignment="Center">
          <Button x:Name="btnSetup"     Content="_Setup"     Margin="0,0,6,0"
                  ToolTip="Run Setup-Stage.ps1 -- seeds module files and synthetic data into C:\Confidential"/>
          <Button x:Name="btnRun"       Content="_Run"       Margin="0,0,10,0"
                  Style="{StaticResource RunButton}"
                  ToolTip="Run the selected profile or stage in the background; output streams to the Activity Log"/>
          <Button x:Name="btnCleanupT1" Content="Clean _initial host" Margin="0,0,6,0"
                  Style="{StaticResource DangerButton}"
                  ToolTip="Run Cleanup-Target1.ps1 -- revert the initial host (scheduled task, staged files, dump locations)"/>
          <Button x:Name="btnCleanupT2" Content="Clean _staged host" Margin="0,0,10,0"
                  Style="{StaticResource DangerButton}"
                  ToolTip="Run Cleanup-Target2.ps1 -- remove lateral-movement and exfil artifacts on the remote host"/>
          <TextBlock x:Name="lblStatus" VerticalAlignment="Center" FontSize="12"
                     FontWeight="SemiBold" Foreground="{StaticResource bBlue}"
                     Visibility="Collapsed" Text="Running&#x2026;"/>
        </WrapPanel>

      </Grid>

    </StackPanel>
    </Grid>

    <GridSplitter Grid.Row="2" HorizontalAlignment="Stretch" VerticalAlignment="Stretch"
                  ResizeDirection="Rows" ResizeBehavior="PreviousAndNext"
                  Background="{StaticResource bGray300}" Margin="12,0" Focusable="True"
                  AutomationProperties.Name="Resize configuration and activity log"
                  ToolTip="Drag to resize the activity log; use arrow keys when focused"/>

    <!-- ══ ACTIVITY LOG ═════════════════════════════════════════════════════ -->
    <Border Grid.Row="3" Margin="12,0,12,8"
            Background="#0B1626"
            BorderBrush="{StaticResource bGray300}" BorderThickness="1"
            CornerRadius="4">
      <Grid>
        <Grid.RowDefinitions>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="*"/>
        </Grid.RowDefinitions>
        <Border Grid.Row="0"
                Background="{StaticResource bGray100}"
                BorderBrush="{StaticResource bGray200}" BorderThickness="0,0,0,1"
                Padding="10,6">
          <DockPanel>
            <StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
              <Button x:Name="btnSaveLog"  Content="Sa_ve Log" Style="{StaticResource MiniButton}"
                      Margin="0,0,6,0" ToolTip="Save the activity log to a file"/>
              <Button x:Name="btnClearLog" Content="C_lear Log" Style="{StaticResource MiniButton}"
                      ToolTip="Clear the activity log"/>
            </StackPanel>
            <TextBlock Style="{StaticResource SecHead}" Text="ACTIVITY LOG" Margin="0" VerticalAlignment="Center"/>
          </DockPanel>
        </Border>
        <RichTextBox Grid.Row="1" x:Name="txtLog"
                     FontFamily="Consolas" FontSize="11"
                     Background="#0B1626" Foreground="#D8E6F2"
                     IsReadOnly="True"
                     BorderThickness="0"
                     Padding="9,7"
                     ScrollViewer.HorizontalScrollBarVisibility="Disabled"
                     ScrollViewer.VerticalScrollBarVisibility="Auto">
          <FlowDocument/>
        </RichTextBox>
      </Grid>
    </Border>

  </Grid>
</Window>
'@

# ─── Load window ─────────────────────────────────────────────────────────────
$reader = [System.Xml.XmlNodeReader]::new($xaml)
try {
    $window = [System.Windows.Markup.XamlReader]::Load($reader)
} catch {
    [System.Windows.MessageBox]::Show(
        "Failed to load UI.`n$($_.Exception.Message)",
        'CBX GUI - Error', 'OK', 'Error')
    return
}

# ─── Control references ──────────────────────────────────────────────────────
function F($n) { $window.FindName($n) }

$runVersion      = F 'runVersion'
$lblAdmin        = F 'lblAdmin'
$btnElevate      = F 'btnElevate'
$rbPrevention    = F 'rbPrevention'
$rbVisibility    = F 'rbVisibility'
$rbSingleStage   = F 'rbSingleStage'
$pnlStageSelect  = F 'pnlStageSelect'
$cmbStage        = F 'cmbStage'
$pnlStageChip    = F 'pnlStageChip'
$lblStageChip    = F 'lblStageChip'
$optScroll       = F 'optScroll'
$pnlVisOpts      = F 'pnlVisOpts'
$txtRemoteTarget = F 'txtRemoteTarget'
$txtUsername     = F 'txtUsername'
$pwdPassword     = F 'pwdPassword'
$chkLocalSim     = F 'chkLocalSim'
$rbCredSession   = F 'rbCredSession'
$rbCredPrompt    = F 'rbCredPrompt'
$rbCredEnter     = F 'rbCredEnter'
$pnlCredFields   = F 'pnlCredFields'
$pwdWatermark    = F 'pwdWatermark'
$pnlPause        = F 'pnlPause'
$txtPauseSeconds = F 'txtPauseSeconds'
$pnlImpact       = F 'pnlImpact'
$lblImpactHead   = F 'lblImpactHead'
$lblS6Note       = F 'lblS6Note'
$txtCanaryPath   = F 'txtCanaryPath'
$btnBrowseCanary = F 'btnBrowseCanary'
$pnlS6Opts       = F 'pnlS6Opts'
$txtFileCount    = F 'txtFileCount'
$txtCanaryAfter  = F 'txtCanaryAfter'
$txtDelayMs      = F 'txtDelayMs'
$lblRunMode      = F 'lblRunMode'
$lblRunTarget    = F 'lblRunTarget'
$lblRunImpact    = F 'lblRunImpact'
$lblValidation   = F 'lblValidation'
$txtCommand      = F 'txtCommand'
$btnCopyCmd      = F 'btnCopyCmd'
$btnRun          = F 'btnRun'
$btnSetup        = F 'btnSetup'
$btnCleanupT1    = F 'btnCleanupT1'
$btnCleanupT2    = F 'btnCleanupT2'
$btnSaveLog      = F 'btnSaveLog'
$btnClearLog     = F 'btnClearLog'
$lblStatus       = F 'lblStatus'
$pnlWWR           = F 'pnlWWR'
$script:txtLog    = F 'txtLog'
$pnlS1Config       = F 'pnlS1Config'
$pnlS2Config       = F 'pnlS2Config'
$rbS2Standard      = F 'rbS2Standard'
$rbS2WebDownload   = F 'rbS2WebDownload'
$pnlS3Config       = F 'pnlS3Config'
$chkDropMasquerade = F 'chkDropMasquerade'
$script:S1Checks  = [ordered]@{
    'systeminfo'       = F 'chkS1_systeminfo'
    'tasklist'         = F 'chkS1_tasklist'
    'ipconfig'         = F 'chkS1_ipconfig'
    'arp'              = F 'chkS1_arp'
    'whoami'           = F 'chkS1_whoami'
    'net_user_local'   = F 'chkS1_net_user_local'
    'net_user_domain'  = F 'chkS1_net_user_domain'
    'net_group_admins' = F 'chkS1_net_group_admins'
    'nltest'           = F 'chkS1_nltest'
    'reg_winver'       = F 'chkS1_reg_winver'
    'reg_defender'     = F 'chkS1_reg_defender'
}

$runVersion.Text = $script:Version

# ─── GUI state (set here so handlers can read it before the first run) ───────
$script:IsRunning = $false

# ─── Activity Log color brushes (dark-terminal palette, bright on #0B1626) ───
$script:LogBrushHeader  = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0x6F, 0xC3, 0xE8))  # light blue  -- GUI run header
$script:LogBrushStep    = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0xE6, 0xB6, 0x55))  # amber   -- Write-Step (console Yellow)
$script:LogBrushStage   = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0x45, 0xD0, 0xCB))  # teal    -- Write-Stage/StageEnd (console Cyan)
$script:LogBrushInfo    = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0x9F, 0xB6, 0xC9))  # slate   -- Write-Info (8-space indent)
$script:LogBrushSuccess = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0x6F, 0xCF, 0x97))  # green   -- exit 0 / [+]
$script:LogBrushError   = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0xFF, 0x8A, 0x80))  # red     -- [ERR] / non-zero exit
$script:LogBrushWarn    = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0xF3, 0xBA, 0x16))  # yellow  -- WARNING / [!]
$script:LogBrushCmd     = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0x8C, 0xA6, 0xBC))  # slate   -- command preview line
$script:LogBrushDefault = New-Object System.Windows.Media.SolidColorBrush(
    [System.Windows.Media.Color]::FromRgb(0xD8, 0xE6, 0xF2))  # light   -- default text

# ─── Stage definitions ───────────────────────────────────────────────────────
$emD = [char]0x2014   # em dash (via char code -> encoding-safe)
$script:Stages = @(
    [PSCustomObject]@{ N=1; Label="1 $emD Discovery  (T1082 / T1087 / T1069 / T1012)"        }
    [PSCustomObject]@{ N=2; Label="2 $emD Credential Access  (LSASS memory, T1003.001)"      }
    [PSCustomObject]@{ N=3; Label="3 $emD Persistence  (Scheduled Task + Encoded PowerShell)"}
    [PSCustomObject]@{ N=4; Label="4 $emD Lateral Movement  (SMB C`$ copy + WMI remote exec)" }
    [PSCustomObject]@{ N=5; Label="5 $emD Exfiltration  (Rename to .jpg + cloud-sync folder)"}
    [PSCustomObject]@{ N=6; Label="6 $emD Impact  (Ransomware sim + CBX canary delete)"      }
)
foreach ($s in $script:Stages) { $cmbStage.Items.Add($s.Label) | Out-Null }
$cmbStage.SelectedIndex = 0

# Stage info-chip metadata (guide section / scorecard id / technique summary).
$script:StageMeta = @{
    1 = @{ Guide='7.1, 7.2';    SC='SC-04';    Desc='systeminfo / tasklist / ipconfig / whoami / net user / reg query' }
    2 = @{ Guide='7.2, 8.2';    SC='SC-04/05'; Desc='LSASS memory credential access via comsvcs.dll MiniDump (T1003.001)' }
    3 = @{ Guide='7.5';         SC='SC-06';    Desc='Register MSTeamsUpdater scheduled task launching encoded PowerShell (-EncodedCommand)' }
    4 = @{ Guide='8.1';         SC='SC-07';    Desc='SMB C$ copy to remote target + WMI remote exec; also runs stages 5 and 6 remotely' }
    5 = @{ Guide='10.1, 10.3';  SC='SC-10';    Desc='Copy files from C:\Confidential renamed to _exfil.jpg into the OneDrive sync folder' }
    6 = @{ Guide='6.4, 7.3, 8.6'; SC='SC-03/08'; Desc='Creates synthetic sandbox, simulates ransomware activity (no encryption), deletes CBX canary file' }
}

# ─── Helpers ─────────────────────────────────────────────────────────────────
function Get-StageN {
    if ($cmbStage.SelectedIndex -ge 0) { return $script:Stages[$cmbStage.SelectedIndex].N }
    return 1
}

function V($ctrl, [bool]$show) {
    $ctrl.Visibility = if ($show) { 'Visible' } else { 'Collapsed' }
}

function Q($path) {
    if ($path -match '\s') { "`"$path`"" } else { $path }
}

# One target resolver is shared by commands, summaries and staged-host cleanup.
function Get-EffectiveRemoteTarget {
    if ($chkLocalSim.IsChecked) { return '' }
    return $txtRemoteTarget.Text.Trim()
}

# Validates the active numeric fields AND repaints their hints/borders (red when
# invalid, muted otherwise). Named Update-* because it mutates UI state; callers
# that only need the boolean also get the paint for free.
function Update-NumericValidation {
    $stage6 = $rbSingleStage.IsChecked -and (Get-StageN) -eq 6
    $fields = @(
        @{ Control=$txtFileCount; Min=20; Max=500; Hint='20-500 synthetic files'; Active=$stage6 },
        @{ Control=$txtCanaryAfter; Min=1; Max=499; Hint='1-499; less than File Count'; Active=$stage6 },
        @{ Control=$txtDelayMs; Min=0; Max=5000; Hint='0-5000 milliseconds'; Active=$stage6 },
        @{ Control=$txtPauseSeconds; Min=0; Max=86400; Hint='0-86400 seconds; 0 = no pause'; Active=[bool]$rbVisibility.IsChecked }
    )
    $valid = $true
    $script:FirstInvalidField = $null
    foreach ($field in $fields) {
        $value = 0
        $errorText = ''
        if ($field.Active) {
            if (-not [int]::TryParse($field.Control.Text.Trim(), [ref]$value) -or
                $value -lt $field.Min -or $value -gt $field.Max) {
                $errorText = "Enter a whole number from $($field.Min) to $($field.Max)."
            } elseif ($field.Control -eq $txtCanaryAfter) {
                $fileCount = 0
                if ([int]::TryParse($txtFileCount.Text.Trim(), [ref]$fileCount) -and
                    $fileCount -ge 20 -and $fileCount -le 500 -and $value -ge $fileCount) {
                    $errorText = 'Must be less than File Count.'
                }
            }
        }
        $hint = F ($field.Control.Name + 'Hint')
        $hint.Text = if ($errorText) { $errorText } else { $field.Hint }
        $hint.Foreground = if ($errorText) { '#961D49' } else { '#5A5A5A' }
        $field.Control.BorderBrush = if ($errorText) { '#961D49' } else { '#CFD3D8' }
        if ($errorText) {
            $valid = $false
            if (-not $script:FirstInvalidField) { $script:FirstInvalidField = $field.Control }
        }
    }
    return $valid
}

function Update-Form {
    $isSingle = [bool]$rbSingleStage.IsChecked
    $isVis    = [bool]$rbVisibility.IsChecked
    $n        = Get-StageN

    V $pnlStageSelect  $isSingle
    V $pnlS1Config     ($isVis -or ($isSingle -and $n -eq 1))   # Stage 1
    V $pnlS2Config     ($isVis -or ($isSingle -and $n -eq 2))   # Stage 2 variant
    V $pnlS3Config     ($isVis -or ($isSingle -and $n -eq 3))   # Stage 3
    V $pnlVisOpts      ($isVis -or ($isSingle -and $n -eq 4))   # Stage 4
    V $pnlImpact       ($isVis -or ($isSingle -and $n -in @(4, 6)))  # Stage 6
    V $pnlS6Opts       ($isSingle -and $n -eq 6)
    V $pnlPause        $isVis      # Stage Pause only affects multi-stage (Visibility) runs
    V $pnlCredFields   ([bool]$rbCredEnter.IsChecked)   # Username/Password only for "Enter now"

    # Context-aware Stage 6 header + chain clarifier (advanced tuning is Single-Stage-6 only)
    if ($isSingle -and $n -eq 4) {
        $lblImpactHead.Text = 'STAGE 6 : IMPACT / CANARY  (via Stage 4 chain)'
    } else {
        $lblImpactHead.Text = 'STAGE 6 : IMPACT / CANARY'
    }
    V $lblS6Note ($isVis -or ($isSingle -and $n -eq 4))

    # Stage info chip
    if ($isSingle -and $script:StageMeta.ContainsKey($n)) {
        $m = $script:StageMeta[$n]
        $desc = $m.Desc
        if ($n -eq 2 -and $rbS2WebDownload.IsChecked) {
            $desc = 'ProcDump download from 3rd-party URL (T1105) + winlogon.exe memory dump (T1003)'
        }
        $lblStageChip.Text = "Guide $($m.Guide)   -   $($m.SC)`r`n$desc"
        V $pnlStageChip $true
    } else {
        V $pnlStageChip $false
    }

    Update-Preview
}

# ─── Command builder (single source of truth for preview AND run) ─────────────
# Returns a hashtable: @{ ScriptFile; ArgList (string[]); Label } for the Run action.
# The early-return on Update-NumericValidation is load-bearing: the [int] casts
# below assume every active numeric field has already passed validation.
function Get-RunSpec {
    if (-not (Update-NumericValidation)) { return $null }
    $n = Get-StageN

    if ($rbPrevention.IsChecked) {
        return @{
            ScriptFile = (Join-Path $script:Dir 'Invoke-Setup.ps1')
            ArgList    = @('-Profile Prevention')
            Label      = 'Prevention Profile (Section 6 -- block mode)'
        }
    }

    if ($rbVisibility.IsChecked) {
        $a  = @('-Profile Visibility')
        $rt = Get-EffectiveRemoteTarget
        if ($rt)                       { $a += "-RemoteTarget $rt" }
        if ($chkLocalSim.IsChecked)    { $a += '-LocalSimulation' }
        if ($rbCredEnter.IsChecked) {
            $un = $txtUsername.Text.Trim(); $pw = $pwdPassword.Password
            if ($un) { $a += "-Username `"$un`"" }
            if ($pw) { $a += "-Password `"$pw`"" }
        } elseif ($rbCredPrompt.IsChecked) { $a += '-PromptCredentials' }
        $cp = $txtCanaryPath.Text.Trim()
        if ($cp)                       { $a += "-CanaryPath $(Q $cp)" }
        $ps = [int]$txtPauseSeconds.Text
        if ($ps -gt 0)                 { $a += "-StagePauseSeconds $ps" }
        $skipped = $script:S1Checks.Keys | Where-Object { -not [bool]$script:S1Checks[$_].IsChecked }
        if ($skipped.Count -gt 0)     { $a += "-SkipDiscovery `"$($skipped -join ',')`"" }
        if ($chkDropMasquerade.IsChecked) { $a += '-DropMasqueradeCopy' }
        if ($rbS2WebDownload.IsChecked)   { $a += '-Stage2Variant WebDownload' }
        $ad = $a | ForEach-Object { if ($_ -match '^-Password ') { '-Password "****"' } else { $_ } }
        return @{
            ScriptFile     = (Join-Path $script:Dir 'Invoke-Setup.ps1')
            ArgList        = $a
            ArgListDisplay = $ad
            Label          = 'Visibility Profile (Sections 7-8-10 -- monitor mode)'
        }
    }

    # Single stage
    if ($n -eq 6) {
        $a  = @()
        $cp = $txtCanaryPath.Text.Trim()
        if ($cp)                 { $a += "-CanaryPath $(Q $cp)" }
        $fc = [int]$txtFileCount.Text
        $ca = [int]$txtCanaryAfter.Text
        $dm = [int]$txtDelayMs.Text
        if ($fc -ne 200)         { $a += "-FileCount $fc" }
        if ($ca -ne 50)          { $a += "-CanaryAfter $ca" }
        if ($dm -gt 0)           { $a += "-DelayMs $dm" }
        $a += '-Force'           # GUI is non-interactive
        return @{
            ScriptFile = (Join-Path $script:Dir 'modules\Stage6-Impact.ps1')
            ArgList    = $a
            Label      = "Single Stage: $($script:Stages[$cmbStage.SelectedIndex].Label)"
        }
    }

    $a = @("-Stage $n")
    if ($n -eq 4) {
        $rt = Get-EffectiveRemoteTarget
        if ($rt)                       { $a += "-RemoteTarget $rt" }
        if ($chkLocalSim.IsChecked)    { $a += '-LocalSimulation' }
        if ($rbCredEnter.IsChecked) {
            $un = $txtUsername.Text.Trim(); $pw = $pwdPassword.Password
            if ($un) { $a += "-Username `"$un`"" }
            if ($pw) { $a += "-Password `"$pw`"" }
        } elseif ($rbCredPrompt.IsChecked) { $a += '-PromptCredentials' }
        $cp = $txtCanaryPath.Text.Trim()
        if ($cp)                       { $a += "-CanaryPath $(Q $cp)" }
    }
    if ($n -eq 1) {
        $skipped = $script:S1Checks.Keys | Where-Object { -not [bool]$script:S1Checks[$_].IsChecked }
        if ($skipped.Count -gt 0) { $a += "-SkipDiscovery `"$($skipped -join ',')`"" }
    }
    if ($n -eq 3 -and $chkDropMasquerade.IsChecked) { $a += '-DropMasqueradeCopy' }
    if ($n -eq 2 -and $rbS2WebDownload.IsChecked)   { $a += '-Stage2Variant WebDownload' }
    $ad = $a | ForEach-Object { if ($_ -match '^-Password ') { '-Password "****"' } else { $_ } }
    return @{
        ScriptFile     = (Join-Path $script:Dir 'Invoke-Setup.ps1')
        ArgList        = $a
        ArgListDisplay = $ad
        Label          = "Single Stage: $($script:Stages[$cmbStage.SelectedIndex].Label)"
    }
}

function Format-Spec {
    param($Spec)
    if (-not $Spec) { return '(select a run mode above)' }
    # Preview shows the REAL command (incl. any -Password) so Copy is runnable and
    # it matches the Activity Log; the cleartext credential is the CBX detection
    # artifact (see the unattended-mode warning). ArgListDisplay is retained but unused.
    $list   = $Spec.ArgList
    $argStr = if ($list.Count) { ' ' + ($list -join ' ') } else { '' }
    "powershell.exe -NoProfile -ExecutionPolicy Bypass -File $(Q $Spec.ScriptFile)$argStr"
}

function Update-Preview {
    $txtRemoteTarget.IsEnabled = -not [bool]$chkLocalSim.IsChecked
    $spec = Get-RunSpec
    $valid = $null -ne $spec
    $txtCommand.Text = if ($valid) { Format-Spec $spec } else { 'Correct the highlighted options to preview the command.' }
    $btnRun.IsEnabled = $valid -and -not $script:IsRunning
    $btnCopyCmd.IsEnabled = $valid
    V $lblValidation (-not $valid)
    Update-ActionSummary
}

# ─── "What Will Run" visual builder (per-stage badge cards) ──────────────────
$script:WwrBlue   = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(0x00,0x5C,0x8A))
$script:WwrNavy   = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(0x01,0x23,0x4D))
$script:WwrGray   = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(0x5A,0x5A,0x5A))
$script:WwrMerlot = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(0x96,0x1D,0x49))
$script:WwrPill   = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(0xE6,0xE8,0xEB))
$script:WwrInk    = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromRgb(0x20,0x20,0x20))

$script:WwrMid = [char]0x00B7   # middle dot  (unicode via char code -> encoding-safe)
$script:WwrEm  = [char]0x2014   # em dash
$script:WwrArr = [char]0x2192   # right arrow

$script:WwrChain = @{
    1 = @{ Name='Discovery';         Desc='Enumerate the host, users & domain';   Tech=@('T1082','T1087','T1069','T1012') }
    2 = @{ Name='Credential Access'; Desc='LSASS memory dump via comsvcs.dll';     Tech=@('T1003.001') }
    3 = @{ Name='Persistence';       Desc='Masquerading scheduled task';           Tech=@('T1053.005','T1059.001') }
    4 = @{ Name='Lateral Movement';  Desc='SMB C$ copy + WMI remote execution';    Tech=@('T1021.002','T1570','T1047') }
    5 = @{ Name='Exfiltration';      Desc='Rename to .jpg into cloud-sync folder';  Tech=@('T1567','T1074') }
    6 = @{ Name='Impact';            Desc='Ransomware sim';                         Tech=@('T1486','T1490'); Danger=$true }
}

# Return the chain entry for $Num, swapping in the Stage 2 WebDownload text when
# that variant is selected so the badge Desc + Tech line match the pill tag.
function Get-WwrChainEntry([int]$Num) {
    $base = $script:WwrChain[$Num]
    if ($Num -eq 2 -and $rbS2WebDownload.IsChecked) {
        $copy = @{}
        foreach ($k in $base.Keys) { $copy[$k] = $base[$k] }
        $copy.Desc = 'ProcDump download, then winlogon.exe memory dump'
        $copy.Tech = @('T1105','T1003')
        return $copy
    }
    return $base
}

function New-WwrTB {
    param([string]$Text='', [double]$Size=11, $Brush=$script:WwrInk, [string]$Weight='Normal',
          [string]$Family='Segoe UI', [bool]$Wrap=$true)
    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text       = $Text
    $tb.FontSize   = $Size
    $tb.Foreground = $Brush
    $tb.FontWeight = [System.Windows.FontWeights]::$Weight
    $tb.FontFamily = New-Object System.Windows.Media.FontFamily($Family)
    if ($Wrap) { $tb.TextWrapping = [System.Windows.TextWrapping]::Wrap }
    return $tb
}

function Add-WwrStage {
    param([int]$Num, [string]$Tag)
    $s = Get-WwrChainEntry $Num

    $grid = New-Object System.Windows.Controls.Grid
    $grid.Margin = [System.Windows.Thickness]::new(0,7,0,0)
    $cA = New-Object System.Windows.Controls.ColumnDefinition; $cA.Width = [System.Windows.GridLength]::Auto
    $cB = New-Object System.Windows.Controls.ColumnDefinition; $cB.Width = New-Object System.Windows.GridLength(1,[System.Windows.GridUnitType]::Star)
    [void]$grid.ColumnDefinitions.Add($cA); [void]$grid.ColumnDefinitions.Add($cB)

    $badge = New-Object System.Windows.Controls.Border
    $badge.Width = 18; $badge.Height = 18
    $badge.CornerRadius      = [System.Windows.CornerRadius]::new(9)
    $badge.Background        = $script:WwrBlue
    $badge.Margin            = [System.Windows.Thickness]::new(0,1,8,0)
    $badge.VerticalAlignment = [System.Windows.VerticalAlignment]::Top
    $bNum = New-WwrTB -Text ([string]$Num) -Size 10 -Brush ([System.Windows.Media.Brushes]::White) -Weight 'SemiBold' -Wrap $false
    $bNum.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Center
    $bNum.VerticalAlignment   = [System.Windows.VerticalAlignment]::Center
    $badge.Child = $bNum
    [System.Windows.Controls.Grid]::SetColumn($badge,0)
    [void]$grid.Children.Add($badge)

    $body = New-Object System.Windows.Controls.StackPanel
    [System.Windows.Controls.Grid]::SetColumn($body,1)

    $nameRow = New-Object System.Windows.Controls.StackPanel
    $nameRow.Orientation = [System.Windows.Controls.Orientation]::Horizontal
    [void]$nameRow.Children.Add((New-WwrTB -Text $s.Name -Size 12 -Brush $script:WwrNavy -Weight 'SemiBold' -Wrap $false))
    if ($Tag) {
        $pill = New-Object System.Windows.Controls.Border
        $pill.CornerRadius      = [System.Windows.CornerRadius]::new(8)
        $pill.Background        = $script:WwrPill
        $pill.Padding           = [System.Windows.Thickness]::new(6,0,6,1)
        $pill.Margin            = [System.Windows.Thickness]::new(7,1,0,0)
        $pill.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
        $pill.Child = New-WwrTB -Text $Tag -Size 9 -Brush $script:WwrGray -Weight 'SemiBold' -Wrap $false
        [void]$nameRow.Children.Add($pill)
    }
    [void]$body.Children.Add($nameRow)

    $desc = New-WwrTB -Size 11 -Brush $script:WwrInk
    $desc.Margin = [System.Windows.Thickness]::new(0,1,0,0)
    if ($s.Danger) {
        [void]$desc.Inlines.Add((New-Object System.Windows.Documents.Run("$($s.Desc) $($script:WwrEm) ")))
        $rd = New-Object System.Windows.Documents.Run('DELETES the canary')
        $rd.Foreground = $script:WwrMerlot; $rd.FontWeight = [System.Windows.FontWeights]::SemiBold
        [void]$desc.Inlines.Add($rd)
        [void]$desc.Inlines.Add((New-Object System.Windows.Documents.Run(' (no encryption)')))
    } else {
        $desc.Text = $s.Desc
    }
    [void]$body.Children.Add($desc)

    $tech = New-WwrTB -Text ($s.Tech -join " $($script:WwrMid) ") -Size 10 -Brush $script:WwrGray -Family 'Consolas' -Wrap $false
    $tech.Margin = [System.Windows.Thickness]::new(0,1,0,0)
    [void]$body.Children.Add($tech)

    [void]$grid.Children.Add($body)
    [void]$pnlWWR.Children.Add($grid)
}

function Add-WwrText {
    param([string]$Text, [double]$Size=10, $Brush=$script:WwrGray, [string]$Weight='SemiBold',
          [bool]$Italic=$false, [double]$Top=0)
    $tb = New-WwrTB -Text $Text -Size $Size -Brush $Brush -Weight $Weight -Wrap $true
    if ($Italic) { $tb.FontStyle = [System.Windows.FontStyles]::Italic }
    $tb.Margin = [System.Windows.Thickness]::new(0,$Top,0,0)
    [void]$pnlWWR.Children.Add($tb)
}

function Add-WwrCheck {
    param([string]$Name, [string]$Tech)
    $g = New-Object System.Windows.Controls.StackPanel
    $g.Orientation = [System.Windows.Controls.Orientation]::Horizontal
    $g.Margin = [System.Windows.Thickness]::new(0,2,0,0)
    $dot = New-Object System.Windows.Controls.Border
    $dot.Width = 5; $dot.Height = 5
    $dot.CornerRadius      = [System.Windows.CornerRadius]::new(3)
    $dot.Background        = $script:WwrGray
    $dot.Margin            = [System.Windows.Thickness]::new(2,0,7,0)
    $dot.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    [void]$g.Children.Add($dot)
    [void]$g.Children.Add((New-WwrTB -Text $Name -Size 11 -Brush $script:WwrInk -Wrap $false))
    [void]$g.Children.Add((New-WwrTB -Text "   $Tech" -Size 10 -Brush $script:WwrGray -Family 'Consolas' -Wrap $false))
    [void]$pnlWWR.Children.Add($g)
}

# Pill tag for the Stage 2 badge: shows WEB DL when the WebDownload variant is
# selected, otherwise $null (no pill). Visibility and single-stage-2 both use it.
function Get-S2VariantTag {
    if ($rbS2WebDownload.IsChecked) { 'WEB DL' } else { $null }
}

function Update-ActionSummary {
    $pnlWWR.Children.Clear()
    $md = $script:WwrMid
    $n = Get-StageN
    $remote = Get-EffectiveRemoteTarget
    $usesStage4 = $rbVisibility.IsChecked -or ($rbSingleStage.IsChecked -and $n -eq 4)
    $target = if ($usesStage4 -and $remote) { $remote }
              elseif ($usesStage4) { 'This host (local simulation)' }
              else { 'This host' }
    $cleanupTarget = if ($remote) { $remote } else { 'This host' }
    $lblRunMode.Text = if ($rbPrevention.IsChecked) { 'Prevention profile - block mode' }
                      elseif ($rbVisibility.IsChecked) { 'Visibility profile - full chain' }
                      else { "Single stage $n - $($script:WwrChain[$n].Name)" }
    $lblRunTarget.Text = if ($usesStage4) { "Stages 5-6 target: $target | Staged-host cleanup: $cleanupTarget" }
                         else { "Run target: $target | Staged-host cleanup: $cleanupTarget" }
    $lblRunTarget.ToolTip = $lblRunTarget.Text
    $lblRunImpact.Text = if ($usesStage4 -or ($rbSingleStage.IsChecked -and $n -eq 6)) {
        'Impact: simulates ransomware on synthetic files and deletes the canary. Confirmation required.'
    } else { 'Impact: no Stage 6 canary deletion in this run.' }
    $btnCleanupT2.ToolTip = "Clean staged-host artifacts on $cleanupTarget (Target 2 cleanup)."
    if ($rbPrevention.IsChecked) {
        Add-WwrText "PREVENTION PROFILE $md SECTION 6 $md BLOCK MODE"
        Add-WwrText 'Automated' -Brush $script:WwrBlue -Top 7
        Add-WwrCheck 'certutil LOTL download' 'T1105'
        Add-WwrCheck 'Encoded PowerShell'     'T1059.001'
        Add-WwrCheck 'TCP port scan'          'T1046'
        Add-WwrText 'Manual (run by hand)' -Brush $script:WwrBlue -Top 8
        Add-WwrCheck 'EICAR test file'          'Sec 6.2'
        Add-WwrCheck 'Stage 6 impact + canary' 'Sec 6.4'
    }
    elseif ($rbVisibility.IsChecked) {
        Add-WwrText "VISIBILITY PROFILE $md FULL CHAIN $md MONITOR MODE"
        Add-WwrStage -Num 1
        Add-WwrStage -Num 2 -Tag (Get-S2VariantTag)
        Add-WwrStage -Num 3
        Add-WwrStage -Num 4
        Add-WwrStage -Num 5 -Tag 'VIA S4'
        Add-WwrStage -Num 6 -Tag 'VIA S4'
        $tgt = if ($remote) { $remote } else { 'this host - local simulation' }
        Add-WwrText "Stages 5-6 run on the Stage 4 target ($tgt)." -Weight 'Normal' -Italic $true -Top 8
    }
    else {
        if ($n -eq 4) {
            Add-WwrText "SINGLE STAGE 4 $md LATERAL MOVEMENT"
            Add-WwrStage -Num 4
            Add-WwrStage -Num 5 -Tag 'VIA S4'
            Add-WwrStage -Num 6 -Tag 'VIA S4'
            Add-WwrText "Stage 4 chains into 5 $($script:WwrArr) 6 on $target." -Weight 'Normal' -Italic $true -Top 8
        } else {
            Add-WwrText "SINGLE STAGE $n $md $($script:WwrChain[$n].Name)"
            $tag = if ($n -eq 2) { Get-S2VariantTag } else { $null }
            Add-WwrStage -Num $n -Tag $tag
        }
    }
}

# ─── Log helpers ─────────────────────────────────────────────────────────────
function Get-LogBrush {
    param([string]$Line)
    # GUI run header: "[2026-10-05 14:30:00]  Label"  (no ms, 2 spaces before label)
    if ($Line -match '^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\]  ') {
        return @{ Brush = $script:LogBrushHeader; Bold = $true }
    }
    # Stage start/end: "==== ..."
    if ($Line -match '^====') {
        return @{ Brush = $script:LogBrushStage; Bold = $true }
    }
    # Script step: "[2026-10-05 14:30:00.123] ..."  (with milliseconds)
    if ($Line -match '^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\]') {
        return @{ Brush = $script:LogBrushStep; Bold = $false }
    }
    # Error lines
    if ($Line -match '^\[ERR\]|^\[ERROR |^SANDBOX SAFETY|^CANARY SAFETY') {
        return @{ Brush = $script:LogBrushError; Bold = $false }
    }
    # Warning lines (Write-Warning adds "WARNING: " prefix)
    if ($Line -match '^WARNING:|^\[!\]') {
        return @{ Brush = $script:LogBrushWarn; Bold = $false }
    }
    # Command preview: indented "  powershell.exe ..." line from run header
    if ($Line -match '^  powershell\.exe ') {
        return @{ Brush = $script:LogBrushCmd; Bold = $false }
    }
    # Info lines: 8-space indent (Write-Info)
    if ($Line -match '^        ') {
        return @{ Brush = $script:LogBrushInfo; Bold = $false }
    }
    # Success
    if ($Line -match '^--- done \(exit 0\)|^\[\+\]') {
        return @{ Brush = $script:LogBrushSuccess; Bold = $false }
    }
    # Non-zero exit
    if ($Line -match '^--- done \(exit ') {
        return @{ Brush = $script:LogBrushError; Bold = $false }
    }
    return @{ Brush = $script:LogBrushDefault; Bold = $false }
}

function Write-Log {
    param([string]$Entry)
    foreach ($line in ($Entry -split "`r`n|`n")) {
        $style = Get-LogBrush $line
        $run   = [System.Windows.Documents.Run]::new($line)
        $run.Foreground = $style.Brush
        if ($style.Bold) { $run.FontWeight = [System.Windows.FontWeights]::SemiBold }
        $para = [System.Windows.Documents.Paragraph]::new($run)
        $para.Margin = [System.Windows.Thickness]::new(0)
        $script:txtLog.Document.Blocks.Add($para)
    }
}

# Enable/disable action buttons while a run is in progress.
function Set-Running {
    param([bool]$Running)
    $script:IsRunning = $Running
    foreach ($b in @($btnSetup, $btnCleanupT1, $btnCleanupT2)) {
        $b.IsEnabled = -not $Running
    }
    $btnRun.IsEnabled = -not $Running -and (Update-NumericValidation)
    V $lblStatus $Running
}

function Clear-ReaderHandles {
    foreach ($h in @($script:PsOut, $script:RsOut, $script:PsErr, $script:RsErr)) {
        if ($h) { try { $h.Dispose() } catch {} }
    }
    $script:PsOut = $null; $script:RsOut = $null
    $script:PsErr = $null; $script:RsErr = $null
}

# ─── Launch helper ───────────────────────────────────────────────────────────
function Invoke-Launch {
    param(
        [string]$ScriptFile,
        [string]$Arguments,
        [string]$Label
    )

    if (-not (Test-Path $ScriptFile)) {
        [System.Windows.MessageBox]::Show(
            "[ERROR] Script not found:`n$ScriptFile", 'CBX GUI', 'OK', 'Warning')
        return
    }

    Set-Running $true

    $argStr = "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptFile`""
    if ($Arguments.Trim()) { $argStr += " $($Arguments.Trim())" }

    $ts    = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $queue = $script:OutputQueue
    # NOTE: the -Password value is shown in clear text here on purpose -- the
    # cleartext credential on the command line is the CBX detection artifact
    # (credential exposure -> investigation flags the account compromised).
    $queue.Enqueue("[$ts]  $Label`r`n  powershell.exe $argStr`r`n")

    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName               = 'powershell.exe'
    $psi.Arguments              = $argStr
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true   # read separately -- MergeStandardErrorToOutput is .NET 6+ only
    $psi.CreateNoWindow         = $true
    $psi.WorkingDirectory       = $script:Dir

    try {
        $proc = [System.Diagnostics.Process]::Start($psi)
    } catch {
        $queue.Enqueue("[ERROR starting process] $_`r`n`r`n")
        $queue.Enqueue("__CBX_RUN_DONE__")
        return
    }

    # Two background runspaces read stdout and stderr concurrently into the shared queue.
    # Concurrent readers avoid the single-thread two-pipe deadlock.
    # Runspaces (not raw .NET threads or event delegates) are required so PowerShell
    # has a runspace on the reading thread -- otherwise WPF crashes on access.
    # The stdout reader enqueues the "__CBX_RUN_DONE__" sentinel last; the UI timer
    # reads it to re-enable the buttons and dispose these runspaces.

    $rsOut = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rsOut.Open()
    $rsOut.SessionStateProxy.SetVariable('proc',  $proc)
    $rsOut.SessionStateProxy.SetVariable('queue', $queue)
    $psOut = [System.Management.Automation.PowerShell]::Create()
    $psOut.Runspace = $rsOut
    [void]$psOut.AddScript({
        try {
            while (-not $proc.StandardOutput.EndOfStream) {
                $line = $proc.StandardOutput.ReadLine()
                if ($null -ne $line) { $queue.Enqueue("$line`r`n") }
            }
            $proc.WaitForExit()
            $queue.Enqueue("--- done (exit $($proc.ExitCode)) ---`r`n`r`n")
        } catch {
            $queue.Enqueue("[ERROR reading stdout] $_`r`n`r`n")
        } finally {
            $queue.Enqueue("__CBX_RUN_DONE__")
        }
    })
    [void]$psOut.BeginInvoke()

    $rsErr = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rsErr.Open()
    $rsErr.SessionStateProxy.SetVariable('proc',  $proc)
    $rsErr.SessionStateProxy.SetVariable('queue', $queue)
    $psErr = [System.Management.Automation.PowerShell]::Create()
    $psErr.Runspace = $rsErr
    [void]$psErr.AddScript({
        try {
            while (-not $proc.StandardError.EndOfStream) {
                $line = $proc.StandardError.ReadLine()
                if ($null -ne $line -and
                    $line -ne '#< CLIXML' -and
                    $line -notmatch '^\s*<Objs\b') {
                    $queue.Enqueue("[ERR] $line`r`n")
                }
            }
        } catch {
            $queue.Enqueue("[ERROR reading stderr] $_`r`n")
        }
    })
    [void]$psErr.BeginInvoke()

    $script:RsOut = $rsOut; $script:PsOut = $psOut
    $script:RsErr = $rsErr; $script:PsErr = $psErr
}

# ─── Run the current selection (with confirmation on destructive actions) ─────
function Invoke-RunSelected {
    $n        = Get-StageN
    $isVis    = [bool]$rbVisibility.IsChecked
    $isSingle = [bool]$rbSingleStage.IsChecked

    $spec = Get-RunSpec
    if (-not $spec) {
        Update-Preview
        if ($script:FirstInvalidField) {
            $script:FirstInvalidField.BringIntoView()
            [void]$script:FirstInvalidField.Focus()
        }
        return
    }

    # Confirmation for destructive / canary-deleting / remote actions.
    $msg = $null
    if ($isVis) {
        $msg = "Run the full Visibility chain?`r`n`r`nStages 1-4 run on this host. Stage 4 also triggers Stage 5 (exfiltration) and Stage 6 (impact), which DELETES the canary file."
    } elseif ($isSingle -and $n -eq 6) {
        $msg = "Stage 6 simulates ransomware activity on synthetic files and DELETES the canary file.`r`n`r`nProceed? (runs with -Force)"
    } elseif ($isSingle -and $n -eq 4) {
        $msg = "Stage 4 performs lateral movement and also triggers Stage 5 (exfiltration) and Stage 6 (impact / canary deletion).`r`n`r`nProceed?"
    }
    if ($msg) {
        $msg += "`r`n`r`n$($lblRunTarget.Text)"
        if ([System.Windows.MessageBox]::Show($msg, 'CBX GUI - Confirm run', 'YesNo', 'Warning') -ne 'Yes') { return }
    }

    Invoke-Launch -ScriptFile $spec.ScriptFile -Arguments ($spec.ArgList -join ' ') -Label $spec.Label
}

# ─── Window loaded ───────────────────────────────────────────────────────────
$window.Add_Loaded({
    if (Test-IsAdmin) {
        $lblAdmin.Text       = '[OK] Running as administrator'
        $lblAdmin.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.Color]::FromRgb(0xA6, 0xE3, 0xA1))   # green
        V $btnElevate $false
    } else {
        $lblAdmin.Text       = '[!] Not elevated -- scripts will fail'
        $lblAdmin.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.Color]::FromRgb(0xF3, 0xBA, 0x16))   # yellow
        V $btnElevate $true
    }
    Update-Form
    $script:txtLog.Document.Blocks.Clear()
    # Log wraps to the viewport (no fixed PageWidth) so there is no always-on
    # horizontal scrollbar; long lines wrap instead of scrolling sideways.
    Write-Log "Ready -- choose a run mode and click Run (or Setup / Cleanup).`r`nOutput streams here. Stage 6 runs with -Force and confirms first.`r`n"
    $script:txtLog.ScrollToEnd()
})

# ─── Event wiring ────────────────────────────────────────────────────────────
$rbPrevention.Add_Checked({  Update-Form })
$rbVisibility.Add_Checked({  Update-Form })
$rbSingleStage.Add_Checked({ Update-Form })
$cmbStage.Add_SelectionChanged({ Update-Form })

# Credential mode radios drive the Username/Password reveal, so re-run the form.
$rbCredSession.Add_Checked({ Update-Form })
$rbCredPrompt.Add_Checked({  Update-Form })
$rbCredEnter.Add_Checked({   Update-Form })

foreach ($ctrl in @($txtRemoteTarget, $txtUsername, $txtPauseSeconds, $txtCanaryPath,
                     $txtFileCount, $txtCanaryAfter, $txtDelayMs)) {
    $ctrl.Add_TextChanged({ Update-Preview })
}
# Password watermark overlay toggles with content (PasswordBox has no native watermark).
$pwdPassword.Add_PasswordChanged({
    $pwdWatermark.Visibility = if ($pwdPassword.Password.Length -eq 0) { 'Visible' } else { 'Collapsed' }
    Update-Preview
})

foreach ($ctrl in @($chkLocalSim, $chkDropMasquerade)) {
    $ctrl.Add_Checked({   Update-Preview })
    $ctrl.Add_Unchecked({ Update-Preview })
}
# Stage 2 variant radios: Update-Form (not Update-Preview) so the Stage-2 info
# chip refreshes. Only the Checked side fires -- Unchecked would double the
# refresh since the paired radio's Checked already covers it.
$rbS2Standard.Add_Checked({    Update-Form })
$rbS2WebDownload.Add_Checked({ Update-Form })
foreach ($ctrl in $script:S1Checks.Values) {
    $ctrl.Add_Checked({   Update-Preview })
    $ctrl.Add_Unchecked({ Update-Preview })
}

# Browse for canary file
$btnBrowseCanary.Add_Click({
    $dlg = [Microsoft.Win32.OpenFileDialog]::new()
    $dlg.Title            = 'Select CBX Canary File'
    $dlg.Filter           = 'Office and image files|*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;*.jpg;*.jpeg|All files|*.*'
    $dlg.InitialDirectory = $env:USERPROFILE
    if ($dlg.ShowDialog($window) -eq $true) {
        $txtCanaryPath.Text       = $dlg.FileName
        $txtCanaryPath.CaretIndex = $txtCanaryPath.Text.Length
    }
})

# DispatcherTimer drains $script:OutputQueue (filled by the reader runspaces on
# background threads) onto the UI-thread TextBox at 100 ms intervals. The
# "__CBX_RUN_DONE__" sentinel re-enables the buttons and disposes the runspaces.
$script:OutputTimer          = New-Object System.Windows.Threading.DispatcherTimer
$script:OutputTimer.Interval = [TimeSpan]::FromMilliseconds(100)
$script:OutputTimer.Add_Tick({
    $item    = $null
    $changed = $false
    while ($script:OutputQueue.TryDequeue([ref]$item)) {
        if ($item -eq '__CBX_RUN_DONE__') {
            Set-Running $false
            Clear-ReaderHandles
            continue
        }
        Write-Log $item
        $changed = $true
    }
    if ($changed) { $script:txtLog.ScrollToEnd() }
})
$script:OutputTimer.Start()

# Primary + action buttons (direct execution)
$btnRun.Add_Click({ Invoke-RunSelected })

$btnSetup.Add_Click({
    Invoke-Launch `
        -ScriptFile (Join-Path $script:Dir 'Setup-Stage.ps1') `
        -Arguments  '' `
        -Label      'Setup -- seed module files and synthetic data'
})

$btnCleanupT1.Add_Click({
    if ([System.Windows.MessageBox]::Show(
            "Revert the initial host (Target 1)?`r`n`r`nRemoves the scheduled task, staged files and dump locations created by the emulation.",
            'CBX GUI - Confirm cleanup', 'YesNo', 'Warning') -ne 'Yes') { return }
    Invoke-Launch `
        -ScriptFile (Join-Path $script:Dir 'Cleanup-Target1.ps1') `
        -Arguments  '' `
        -Label      'Cleanup Target 1'
})

function Get-StagedCleanupSpec {
    $rt = Get-EffectiveRemoteTarget
    if ($rt) {
        $cleanupArgs = "-RemoteTarget $rt"
        $un = $txtUsername.Text.Trim(); $pw = $pwdPassword.Password
        if ($rbCredEnter.IsChecked -and $un -and $pw) {
            $cleanupArgs += " -Username `"$un`" -Password `"$pw`""
        } elseif ($rbCredPrompt.IsChecked) { $cleanupArgs += ' -PromptCredentials' }
        return @{
            ScriptFile = (Join-Path $script:Dir 'Invoke-RemoteCleanup.ps1')
            Arguments  = $cleanupArgs
            Label      = "Cleanup staged host (remote: $rt)"
            Confirm    = "Clean the remote host ($rt)?`r`n`r`nRemoves lateral-movement and exfil artifacts left by Stage 4/5/6 on $rt."
        }
    } else {
        return @{
            ScriptFile = (Join-Path $script:Dir 'Cleanup-Target2.ps1')
            Arguments  = ''
            Label      = 'Cleanup staged host (this host)'
            Confirm    = "Clean staged-host artifacts on this host?`r`n`r`nRemoves lateral-movement and exfil artifacts from local simulation."
        }
    }
}

$btnCleanupT2.Add_Click({
    $spec = Get-StagedCleanupSpec
    if ([System.Windows.MessageBox]::Show($spec.Confirm, 'CBX GUI - Confirm cleanup', 'YesNo', 'Warning') -ne 'Yes') { return }
    Invoke-Launch -ScriptFile $spec.ScriptFile -Arguments $spec.Arguments -Label $spec.Label
})

# Utility buttons
$btnCopyCmd.Add_Click({
    try { [System.Windows.Clipboard]::SetText($txtCommand.Text) } catch {}
})

$btnSaveLog.Add_Click({
    $dlg = [Microsoft.Win32.SaveFileDialog]::new()
    $dlg.Title    = 'Save Activity Log'
    $dlg.Filter   = 'Log files|*.log|Text files|*.txt|All files|*.*'
    $dlg.FileName = "CBX-POC-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
    if ($dlg.ShowDialog($window) -eq $true) {
        try {
            $range = New-Object System.Windows.Documents.TextRange(
                $script:txtLog.Document.ContentStart,
                $script:txtLog.Document.ContentEnd)
            [System.IO.File]::WriteAllText($dlg.FileName, $range.Text)
        }
        catch { [System.Windows.MessageBox]::Show("Could not save log:`n$_", 'CBX GUI', 'OK', 'Warning') }
    }
})

$btnClearLog.Add_Click({ $script:txtLog.Document.Blocks.Clear() })

# Relaunch elevated (shown only when not already admin)
$btnElevate.Add_Click({
    try {
        $hostExe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        $psi  = [System.Diagnostics.ProcessStartInfo]::new()
        $psi.FileName        = $hostExe
        $psi.Arguments       = "-NoProfile -ExecutionPolicy Bypass -File `"$script:SelfPath`""
        $psi.WorkingDirectory = $script:Dir
        $psi.Verb            = 'runas'
        $psi.UseShellExecute = $true
        [void][System.Diagnostics.Process]::Start($psi)
        $window.Close()
    } catch {
        # User cancelled the UAC prompt, or elevation failed -- leave the current window open.
    }
})

# ─── Show window ─────────────────────────────────────────────────────────────
[void]$window.ShowDialog()
