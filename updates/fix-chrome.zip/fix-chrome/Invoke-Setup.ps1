# ============================================================================
# Invoke-AttackChain.ps1  -  Two-profile runner for the staged emulation
# ----------------------------------------------------------------------------
# Orchestrates the stage modules. Run from an elevated PowerShell prompt on the
# initial host (Target 1), after Setup-Stage.ps1.
#
# PROFILES
#   Prevention   Benign single-technique checks for POC-Prevention (block mode).
#                Maps to guide section 6. (Prevention-Checks.ps1 + Stage6 canary.)
#   Visibility   Full six-stage chain for POC-Visibility (Monitor mode).
#                Maps to guide sections 7, 8 and 10. Use -RemoteTarget for the
#                cross-device lateral-movement graph, or -LocalSimulation.
#
# EXAMPLES
#   .\Invoke-AttackChain.ps1 -Profile Prevention
#   .\Invoke-AttackChain.ps1 -Profile Visibility -RemoteTarget LAB-WIN2
#   .\Invoke-AttackChain.ps1 -Profile Visibility -LocalSimulation
#   .\Invoke-AttackChain.ps1 -Stage 3                 # run one stage, pause, screenshot
#
# SAFETY: isolated, snapshotted lab hosts only; test users, synthetic data.
# In the CBX-US lab keep activity off the MS_ and BH_ device groups.
# ============================================================================
[CmdletBinding(DefaultParameterSetName='Profile')]
param(
    [Parameter(ParameterSetName='Profile')]
    [ValidateSet('Prevention','Visibility')]
    [string]$Profile = 'Visibility',

    [Parameter(ParameterSetName='Stage')]
    [ValidateRange(1,6)]
    [int]$Stage,

    [string]$RemoteTarget,
    [switch]$PromptCredentials,
    [string]$Username,
    [string]$Password,
    [switch]$LocalSimulation,
    [string]$CanaryPath,
    [int]$StagePauseSeconds = 0,    # pause between stages so alerts land before the next one
    [string]$SkipDiscovery  = '',   # comma-separated Stage 1 command keys to skip
    [switch]$DropMasqueradeCopy,    # Stage 3: drop a renamed powershell.exe as ms_teams.exe (T1036.005)

    # Stage 2 variant: 'Standard' = comsvcs.dll MiniDump (T1003.001 only).
    # 'WebDownload' fetches ProcDump from a 3rd-party URL first (T1105 + T1003.001)
    # so Web Security + endpoint both fire and the Threat Tracer graph chains them.
    [ValidateSet('Standard','WebDownload')]
    [string]$Stage2Variant = 'Standard'
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $scriptDir 'lib\Common.ps1')
$mod = Join-Path $scriptDir 'modules'

try { Assert-Admin } catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; return }

function Invoke-Stage {
    param([int]$N)
    switch ($N) {
        1 { & (Join-Path $mod 'Stage1-Discovery.ps1') -SkipDiscovery $SkipDiscovery }
        2 {
            $s2Script = if ($Stage2Variant -eq 'WebDownload') { 'Stage2b-WebDownloadCredAccess.ps1' }
                        else                                   { 'Chrome-Update.ps1' }
            & (Join-Path $mod $s2Script)
        }
        3 { & (Join-Path $mod 'Stage3-Persistence.ps1') -DropMasqueradeCopy:$DropMasqueradeCopy }
        4 { & (Join-Path $mod 'UpdateCheck.ps1') -RemoteTarget $RemoteTarget `
                -PromptCredentials:$PromptCredentials -Username $Username -Password $Password `
                -LocalSimulation:$LocalSimulation -CanaryPath $CanaryPath }
        5 { & (Join-Path $mod 'Stage5-Exfiltration.ps1') }
        6 {
            if ([string]::IsNullOrWhiteSpace($CanaryPath)) {
                throw 'Stage 6 requires -CanaryPath. Choose the test canary explicitly.'
            }
            & (Join-Path $mod 'Stage6-Impact.ps1') -CanaryPath $CanaryPath -Force  # non-interactive chain run
        }
    }
    if ($StagePauseSeconds -gt 0 -and $N -lt 6) {
        Write-Info "pausing $StagePauseSeconds s so alerts land before the next stage..."
        Start-Sleep -Seconds $StagePauseSeconds
    }
}

# ---- single stage ----
if ($PSCmdlet.ParameterSetName -eq 'Stage') {
    Write-Host "Running single stage $Stage" -ForegroundColor Green
    if ($Stage -eq 6 -and [string]::IsNullOrWhiteSpace($CanaryPath)) {
        Write-Host '[!] Stage 6 requires -CanaryPath.' -ForegroundColor Red
        return
    }
    Invoke-Stage -N $Stage
    Write-Host "[+] Stage $Stage complete." -ForegroundColor Green
    return
}

# ---- profiles ----
if ($Profile -eq 'Prevention') {
    Write-Host "PROFILE: Prevention (section 6, block mode)" -ForegroundColor Green
    & (Join-Path $mod 'Prevention-Checks.ps1')
    Write-Host "[i] For 6.4, run Stage6-Impact.ps1 on a POC-Prevention host." -ForegroundColor DarkGray
    Write-Host "[+] Prevention profile complete." -ForegroundColor Green
    return
}

# Visibility: full ordered chain. Stage 4 runs 5+6 (remotely on Target 2, or
# locally with -LocalSimulation), so the runner does not call 5/6 again.
Write-Host "PROFILE: Visibility (sections 7-8-10, Monitor mode)" -ForegroundColor Green
if (-not $RemoteTarget -and -not $LocalSimulation) {
    Write-Host "[i] No -RemoteTarget given; stage 4 will run in local simulation (no cross-device graph)." -ForegroundColor DarkGray
}
$startedAt = Get-Date
1..4 | ForEach-Object { Invoke-Stage -N $_ }
Write-Host ""
Write-Host "[+] Visibility chain complete. Run started $($startedAt.ToString('yyyy-MM-dd HH:mm:ss'))." -ForegroundColor Green
Write-Host "    Note the start time above against the Analytics investigation creation time (SC-04)." -ForegroundColor DarkGray
